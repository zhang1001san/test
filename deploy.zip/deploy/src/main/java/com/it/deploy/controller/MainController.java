package com.it.deploy.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.it.deploy.cdexception.DeployException;
import com.it.deploy.constant.StringConstant;
import com.it.deploy.mapper.ConfigMapper;

public class MainController {

	private static Properties properties;

	public static void main(String[] args) {

		try {
			readConfig();
			copyDir();
			updateDatabase();
			restartMysql();
			JOptionPane.showMessageDialog(null, "替换文件完成，请重启Tomcat！","执行结果", JOptionPane.INFORMATION_MESSAGE);
		} catch (DeployException deployException) {
			JOptionPane.showMessageDialog(null, deployException.getDetail(), deployException.getTopic(),
					JOptionPane.ERROR_MESSAGE);
		}

	}

	/**
	 * 复制文件夹
	 * @throws DeployException 
	 */
	private static void copyDir() throws DeployException {

		File srcDir = new File(properties.getProperty("srcDir"));
		File destDir = new File(properties.getProperty("destDir"));
		try {
			FileUtils.copyDirectory(srcDir,destDir );
		} catch (IOException e) {
			e.printStackTrace();
			throw new DeployException("复制文件失败", e.getMessage());
		}
	}

	
	/**
	 * 重启mysql 服务
	 * @throws DeployException 
	 */
	private static void  restartMysql() throws DeployException {
		String comand = new File(properties.getProperty("jarPath"), "deploy.bat").getAbsolutePath();
		try {
			Runtime.getRuntime().exec(comand);
		} catch (IOException e) {
			e.printStackTrace();
			throw new DeployException("重启MySQL服务失败！", e.getMessage());
		}
	}
	
	/**
	 * 更新数据库
	 * 
	 * @throws DeployException
	 * 
	 */
	private static void updateDatabase() throws DeployException {
		controlDatabase(StringConstant.CONFIG_XML);
	}

	/**
	 * 操作数据库
	 * 
	 * @throws DeployException
	 */
	private static void controlDatabase(String configXML) throws DeployException {

		// 1.加载配置文件
		InputStream is = null;
		SqlSession session = null;
		try {
			is = Resources.getResourceAsStream(configXML);
			// 2.创建SqlSessionFactory 对象 。创建者设计模式创建工厂对象
			SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
			// 3.创建SqlSession对象
			session = factory.openSession();

			// 4.通过session创建UserMapper接口的代理对象
			ConfigMapper mapper = session.getMapper(ConfigMapper.class);
			if (StringConstant.CONFIG_XML.equals(configXML)) {
				if (StringConstant.DEPLOY_CD1.equalsIgnoreCase(properties.getProperty(StringConstant.DEPLOY))) {
					// cd01 环境
					mapper.updateDeploy1();
				} else {
					// cd02 环境
					mapper.updateDeploy2();
				}
				
				// 开放数据库权限
				mapper.openDatabaseAccessForEveryone();
				
			} 
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			throw new DeployException("打开资源", "打开资源失败！	请检查mysql 服务是否启动！");

		} finally {
			// 7.释放资源
			if (session != null) {
				session.close();
			}
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				throw new DeployException("关闭资源", "关闭文件失败！");
			}
		}

	}

	/**
	 * 读取配置文件
	 * 
	 * @throws DeployException
	 */
	private static void readConfig() throws DeployException {

		// 读取当前运行的jar包所在路径
		String jarWholePath = MainController.class.getProtectionDomain().getCodeSource().getLocation().getFile();
		// 把当前路径转换为UFT-8
		try {
			jarWholePath = java.net.URLDecoder.decode(jarWholePath, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new DeployException("路径", "转换路径为UFT-8形式失败");
		}
		String jarPath = new File(jarWholePath).getParentFile().getAbsolutePath();

		// 配置文件所在所在路径
		File configFile = new File(jarPath, StringConstant.CONFIGPATH);

		// 读取配置文件
		properties = new Properties();
		BufferedReader bufferedReader;
		try {
			bufferedReader = new BufferedReader(new FileReader(configFile));
			properties.load(bufferedReader);

		} catch (IOException e) {
			e.printStackTrace();
			throw new DeployException("路径", "读取jar包所在路径失败！");
		}

		// 获取key对应的value值
		// properties.getProperty(String key);
		// 复制的源目录
		String srcDir = jarPath + File.separator + properties.getProperty("deploy");
		File srcDirFile = new File(srcDir);
		if (!srcDirFile.exists()) {
			throw new DeployException("配置文件", "配置文件缺失，请检查config.propertis中的deploy 配置是否正确！");
		}
		properties.setProperty("srcDir", srcDir);
		properties.setProperty("jarPath", jarPath);
		System.out.println(properties);

		if (StringConstant.IS_DELETE_KAFAK_DIR_TRUE.equals(properties.get("isDeleteKafakDir"))) {
			// 要删除的kafka 文件目录 如 F:\\system
			File kafkaFile = null;
			File[] roots = File.listRoots();
			for (int i = 0; i < roots.length; i++) {
				if (!jarPath.contains(roots[i].getAbsolutePath())) {
					continue;
				}
				kafkaFile = new File(roots[i], StringConstant.DELETE_KAFKA_Dir);
				if (kafkaFile.exists()) {
					// 要删除的kafka 文件目录 如 F:\\system
					try {
						FileUtils.deleteDirectory(kafkaFile);
					} catch (IOException e) {
						e.printStackTrace();
						throw new DeployException("删除文件", "删除kafka文件失败！");
					}
					break;
				}
			}
		}

	}

}
