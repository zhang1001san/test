package com.it.deploy.mapper;

public interface ConfigMapper {
	
	/**
	 * 更新数据
	 */
	public void updateDeploy1();
	
	/**
	 * 更新数据
	 */
	public void updateDeploy2();
	
	/**
	 * 开放数据库权限
	 */
	public void openDatabaseAccessForEveryone();

}
