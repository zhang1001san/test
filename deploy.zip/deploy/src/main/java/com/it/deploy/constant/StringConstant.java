package com.it.deploy.constant;

public interface StringConstant {
	/**
	 * 配置文件所在路径
	 */
	String CONFIGPATH = "config.properties";
	
	/**
	 * 要删除的kafka 文件路径
	 */
	String DELETE_KAFKA_Dir = "system";
	
	/**
	 * 是否删除kafka文件
	 */
	String IS_DELETE_KAFAK_DIR_TRUE="true";
	
	String  CONFIG_XML ="SqlMapConfig.xml";
	
	/**
	 * 部署场景  cd01/cd02
	 */
	String DEPLOY = "deploy";
	
	String DEPLOY_CD1 = "cd01";
	

}
