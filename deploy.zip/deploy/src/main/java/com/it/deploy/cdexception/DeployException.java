package com.it.deploy.cdexception;

public class DeployException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 主题
	 */
	private String topic;

	/**
	 * 错误详情
	 */
	private String detail;

	public DeployException(String detail) {
		super();
		this.detail = detail;
	}

	public DeployException(String topic, String detail) {
		super();
		this.topic = topic;
		this.detail = detail;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

}
