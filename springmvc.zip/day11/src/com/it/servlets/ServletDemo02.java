package com.it.servlets;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 获取请求头信息
 * 	request.getHeader(name);  //根据名称获取对应的值
	request.getHeaderNames(); //获取所有请求头的名称
 * @author Administrator
 *
 */

public class ServletDemo02 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		request.getHeader(name)
//		request.getHeaderNames();
//		request.getDateHeader(name)
//		request.getIntHeader(name);
		
		//获取请求头信息
		//获取所有请求头的name
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String name = (String) headerNames.nextElement();
			//获取请求头的name 对应的value
			String value = request.getHeader(name);
			System.out.println(name+" = "+value);
			
		}
		
	}

}