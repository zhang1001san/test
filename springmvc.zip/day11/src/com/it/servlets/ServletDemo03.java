package com.it.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * requet获取请求体的信息
 * @author Administrator
 *
 */
public class ServletDemo03 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/*
	POST  /day32_v1/ServletDemo03  HTTP/1.1
	请求头
	请求头
	请求头
	空行
	username=tom&password=1234&hobby=qdm&hobby=kdm&hobby=tdm
	
	request可以获取到的请求体键值对的数据
	请求行通过键值对向服务端传递的数据也可以获取到
	
	*/
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//获取请求体参数
		//通过表单的name获取value
		String username = request.getParameter("username");
		String  password = request.getParameter("password");
		String[] hobbies = request.getParameterValues("hobby");//爱好有多个，用数组存
		System.out.println("username = "+username);
		System.out.println("password = "+password);
		System.out.println(Arrays.toString(hobbies));
		
		System.out.println("================ 获取表单所有的name  ==================");
		Enumeration<String> parameterNames = request.getParameterNames();
		while (parameterNames.hasMoreElements()) {
			String name = (String) parameterNames.nextElement();
			System.out.println(name);
			
		}
		
		//获取表单的所有信息 这些信息存到map中
		System.out.println("=========获取表单的所有的 信息 ，这些信息存在map 中=============");
		Map<String, String[]> map = request.getParameterMap();
		Set<String> keySet = map.keySet();
		for (String name : keySet) {
			String[] value = map.get(name);
			System.out.println(name+" = "+Arrays.toString(value));
		}
		
	}

}