package com.it.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 通过request获取请求行的信息
 * 
 */


public class ServletDemo01 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//浏览器输入：http://192.168.159.23:8080/day11/ServletDemo01?name=zhang&age=18
		//测试的时候把ip	http://192.168.159.23换成自己电脑对应的ip就行
		
		
		//1.本次请求的方法  GET/POST		
		System.out.println("request.getMethod():"+request.getMethod());
		//request.getMethod():GET
		
		//2.获取到本次请求项目名称对应路径		
		System.out.println("request.getRequestURI():"+request.getRequestURI());
		//request.getRequestURI():/day11/ServletDemo01
		
		//3.获取到用户浏览器地址栏中的路径(不包括参数部分)
		System.out.println("request.getRequestURL():"+request.getRequestURL());
		//request.getRequestURL():http://192.168.159.23:8080/day11/ServletDemo01
		
		//4.name=zhang&age=18  以GET方式发送到服务端的参数部分		
		System.out.println("request.getQueryString():"+request.getQueryString());
		//request.getQueryString():name=zhang&age=18
		
		//5.HTTP/1.1  本次请求的协议以及版本		
		System.out.println("request.getProtocol():"+request.getProtocol());
		//request.getProtocol():HTTP/1.1
		
		//6.项目名称 
		System.out.println("request.getContextPath():"+request.getContextPath());
		//request.getContextPath():/day11
		
		//7.demo01  本次请求的Servlet对应的路径				
		System.out.println("request.getServletPath():"+request.getServletPath());
		//request.getServletPath():/ServletDemo01
		
		//8.通过底层的socket获取到的客户端的IP		
		//代码是运行在服务端的.对于服务端来说,大家的机器就是远程的
		System.out.println("request.getRemoteAddr():"+request.getRemoteAddr());
		//request.getRemoteAddr():192.168.159.26
		
		//9.获取远程机器的主机名,如果获取不到默认还是IP		
		System.out.println("request.getRemoteHost():"+request.getRemoteHost());
		//request.getRemoteHost():192.168.159.26
		
		//10.获取远程机器的端口号   8080是服务端对外提供的端口号   
		//客户端的数据要传递到服务端,也需要从一个端口号来进行传递,
		//客户端的端口号是系统随机分配的		
		System.out.println("request.getRemotePort():"+request.getRemotePort());
		//request.getRemotePort():59806
		
		//11.获取到本地的服务端的ip 192.168.42.94
		System.out.println("request.getLocalAddr():"+request.getLocalAddr());
		//request.getLocalAddr():192.168.159.23
		
		//12.获取到服务端的主机名称   	
		System.out.println("request.getLocalName():"+request.getLocalName());
		//request.getLocalName():CY-20170310EQEI
		
		//13.获取到服务端的端口号    8080		
		System.out.println("request.getLocalPort():"+request.getLocalPort());
		//request.getLocalPort():8080
		
		//14.获取服务器的主机名 如果获取不到默认还是IP	
		System.out.println("request.getServerName():"+request.getServerName());
		//request.getServerName():192.168.159.23
		
		//15.获取服务器的端口号  8080				
		System.out.println("request.getServerPort():"+request.getServerPort());
		//request.getServerPort():8080
		
		//16.获取本次请求的协议  HTTP				
		System.out.println("request.getScheme():"+request.getScheme());
		//request.getScheme():http
		
	}

}