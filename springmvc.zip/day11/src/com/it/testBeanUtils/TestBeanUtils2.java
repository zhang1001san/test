package com.it.testBeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

import com.it.domain.User;

public class TestBeanUtils2 {
	public static void main(String[] args) throws IllegalAccessException, InvocationTargetException {
//		模拟表单传来的数据。并把这些数据封装成一个对象
//		封装表单数据,使用Map模拟request.getParameterMap()
		HashMap<String,String[]> map = new HashMap<String,String[]>();
		map.put("username", new String[]{"zhang"});
		map.put("password", new String[]{"123456"});
		map.put("age", new String[]{"18"});
		map.put("hobby", new String[]{"篮球","排球","羽毛球"});
		map.put("birthday", new String[]{"1994-1-5"});
		
		//1 创建BeanUtils提供时间转换器
		DateConverter dateConverter = new DateConverter();
		
		//2 设置需要转换的格式
//		dateConverter.setPattern("yyyy-MM-dd");
		//或者设置需要转换的格式
		String[] patterns=new String[]{"yyyy-MM-dd","yyyy-MM-dd HH:mm:ss"};
		dateConverter.setPatterns(patterns);
		
		//3 注册转换器
		ConvertUtils.register(dateConverter, java.util.Date.class);
	
		User user = new User();
		BeanUtils.populate(user, map);;
		System.out.println(user);
		
	}

}
