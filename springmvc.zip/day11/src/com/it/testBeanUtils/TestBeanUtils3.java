package com.it.testBeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

import com.it.domain.User;
import com.it.utils.MyBeanUtils;

/**
 * 使用自己封装的工具类来实现日期类型转换
 * @author Administrator
 *
 */

public class TestBeanUtils3 {
	public static void main(String[] args) throws IllegalAccessException, InvocationTargetException {
//		模拟表单传来的数据。并把这些数据封装成一个对象
//		封装表单数据,使用Map模拟request.getParameterMap()
		HashMap<String,String[]> map = new HashMap<String,String[]>();
		map.put("username", new String[]{"zhang"});
		map.put("password", new String[]{"123456"});
		map.put("age", new String[]{"18"});
		map.put("hobby", new String[]{"篮球","排球","羽毛球"});
		map.put("birthday", new String[]{"1994-1-5"});
		

		//使用自己封装的工具类来实现日期类型转换
		
		//1.MyBeanUtils第一种用法
//		User user = new User();
//		MyBeanUtils.populate(user, map);
//		System.out.println(user);
	
		//2.MyBeanUtils第二种用法
		User populate = MyBeanUtils.populate(User.class, map);
		System.out.println(populate);
		
		
	}

}
