package com.it.testBeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;

import com.it.domain.User;

public class TestBeanUtils01 {
	public static void main(String[] args) throws IllegalAccessException, InvocationTargetException {
//		模拟表单传来的数据。并把这些数据封装成一个对象
//		封装表单数据,使用Map模拟request.getParameterMap()
		HashMap<String,String[]> map = new HashMap<String,String[]>();
		map.put("username", new String[]{"zhang"});
		map.put("password", new String[]{"123456"});
		map.put("age", new String[]{"18"});
		map.put("hobby", new String[]{"篮球","排球","羽毛球"});
		
		User user = new User();
		BeanUtils.populate(user, map);;
		System.out.println(user);
		
	}

}
