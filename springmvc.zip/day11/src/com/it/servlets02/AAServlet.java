package com.it.servlets02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * #_request实现请求转发
	1.什么是请求转发_重点
	服务端有2个Servlet,名称为AAServlet/BBServlet,当我们从客户端向服务端AAServlet
	发起请求的时候,在AAServlet中没有立即进行响应(即使在AAServlet中对客户端进行响应也
	无法将内容响应到客户端),而是将request/response继续向后传递,传递到BBServlet,在
	BBServlet中完成了本次响应.

	2.为什么要有请求转发?
	因为本次请求到服务端希望做一些事情,但是在AAServlet做这件事情不合适,将要实现的功能分为2步来实现,
	一部分事情在AAServlet实现,剩余部分在BBServlet实现

	3.请求转发本质什么什么?
	服务端有2个Servlet(AAServlet,BBServlet),AAServlet执行完毕之后,执行BBServlet,
	AAServlet和BBServlet	共享同一对request/response.
	注意:请求转发只能在当前项目内进行
	请求转发路径:看到的是第一个AAServlet路径,无法看到BBServlet路径

 * 
 * 
 * 
 * 
 * 
 * 通过request实现请求转发
 *	1.浏览器输入：http://localhost:8080/day11/AAServlet
 *		然后服务器在AAServlet给浏览器响应数据。这个响应数据传到不到浏览器
 *	2.通过request获取调度器，把AAServlet的request和response传到BBServlet.
 *	3.BBServlet响应数据到浏览器
 *	
 *注意：虽然是BBServlet响应数据到浏览器，但是浏览器的地址却没有变成http://localhost:8080/day11/BBServlet
 *		而是始终为http://localhost:8080/day11/AAServlet 
 *	这点和重定向不同。
 *
 *
 */

public class AAServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("AAServlet...");
		//1.向request的attribute的map 中添加数据
		request.setAttribute("username", "root");
		request.setAttribute("password", "123456");
		
		//2.向客户端响应部分信息 --->无法响应
		PrintWriter writer = response.getWriter();
		writer.println("message send from AAServlet");
		
		//3.通过request实现请求转发
		//3.1获取调度器，告诉调度器转发到哪里
		//requestDispatcher:Tomcat内部API,类似五叉路口交警
		//RequestDispatcher通过/BBServlet在web.xml寻找/BBServlet全路径
		//通过反射创建BBServlet对象 -->调用BBServlet的init()方法 --->调用BBServlet的service()方法
		RequestDispatcher dispatcher = request.getRequestDispatcher("/BBServlet");
		
		//3.2.调度器将当前的request和response继续向后传递，传到/BBServlet
		//然后找到BBServlet,调用BBServlet的init()方法 --->调用BBServlet的service()方法
		dispatcher.forward(request, response);
		
		//4.向客户端响应部分信息 --->无法响应(无论是请求转发前还是请求转发后,AAServlet都无法向浏览器响应信息)
		writer.println("message send from AAServlet  after");
		
	}

}
