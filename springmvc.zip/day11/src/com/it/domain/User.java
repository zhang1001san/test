package com.it.domain;

import java.util.Arrays;
import java.util.Date;

/**
 * User的成员变量名称与表单的name严格一致。
 * 如果表单的name = username,那么User就需要
 * 一个成员变量 private String username;
 * 
 * 此外，还需要实现setXXX,getXXX方法
 * @author Administrator
 *
 */
public class User {
	private String username;
	private String password;
	private int age;
	private String[] hobby;
	private Date birthday;//生日
	public User() {
		super();
	}
	
	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getHobby() {
		return hobby;
	}
	public void setHobby(String[] hobby) {
		this.hobby = hobby;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", age=" + age + ", hobby="
				+ Arrays.toString(hobby) + ", birthday=" + birthday + "]";
	}

	

}
