package com.it.servlets03;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 请求体有中文
	如：以POST方式提交表单数据到服务器。如果表单的内容有中文会乱码
	  //告诉tomcat请求体部分采用的编码格式 （如html页面采用utf-8）
	  request.setCharacterEncoding(“utf-8”);
	  request.getParameter(“username”);
	  
	POST  /day33_v1/ServletDemo01 http/1.1
	请求头
	请求头
	请求头
	空行
	name=张三
 * @author Administrator
 *
 */
public class ServletDemo06 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//以POST方式提交表单数据中文乱码
		//设置请求体部分的中文编码格式(因为form2.htm2的编码为utf-8.)。
		//简单来说，就是用什么编码方式编码，就用什么方式解码
		request.setCharacterEncoding("utf-8");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println("username = "+username);
		System.out.println("password = "+password);
	}

}