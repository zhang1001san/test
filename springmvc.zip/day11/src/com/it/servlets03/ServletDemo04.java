package com.it.servlets03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
	响应体有中文，会乱码
		如：服务端向客户端响应内容中有中文乱码
	响应体中中文乱码
	解决方法：
	response.setContentType("text/html;charset=utf-8");
 *
 */

public class ServletDemo04 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		解决服务端向客户端响应内容中有中文乱码
//		响应体中中文乱码
		//解决方法：设置响应的内容的编码为utf-8
		response.setContentType("text/html;charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.println("服务器发来的消息");
		
	}

}