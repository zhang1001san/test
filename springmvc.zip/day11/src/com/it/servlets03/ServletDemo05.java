package com.it.servlets03;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 请求头有中文
		如：以GET方式提交表单数据到服务器。如果表单的内容有中文，会乱码
	 HTTP协议请求行中文
	 如：
	GET  /day33_v1/ServletDemo01?name=中文 http/1.1
	请求头
	请求头
	请求头
	空行
	 
	  Servlet中处理
	  Strng name=request.getParameter("name");
	  String fName=new String(name.getBytes(“iso-8859-1”),”utf-8”);
 *
 *
 */
public class ServletDemo05 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//获取表单内容
		//String fName=new String(name.getBytes(“iso-8859-1”),”utf-8”);
		/**
		 * 解释：
		 * 浏览器把以下内容传过来
		 
		 GET /day11/ServletDemo05?username=张三&password=12345 http/1.1
			请求头
			请求头
			请求头
			空行
			请求行有中文。当时http协议的请求行不支持中文！
		浏览器会把浏览器的全部内容了用iso-8859-1编码。然后传到服务器。
		这样服务器收到的内容都是iso-8859-1编码的。那就用iso-8859-1解码
		然后转换为字节数组
			tempUsername.getBytes("iso-8859-1")
		然后把字节数组用utf-8编码。utf-8支持中文。
		 */
		
		String tempUsername = request.getParameter("username");
		String username = new String(tempUsername.getBytes("iso-8859-1"),"utf-8");
		
		String tempPassword = request.getParameter("password");
		String password = new String(tempPassword.getBytes("iso-8859-1"),"utf-8");
		
		System.out.println("username = "+username);
		System.out.println("password = "+password);
	}

}