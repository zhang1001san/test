package com.it.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFirstServlet  implements Servlet{

	
	static{
		System.out.println("MyFirstServlet.class 被加载到内存");
	}
	
	public MyFirstServlet() {
		System.out.println("MyFirstServlet 构造方法执行");
	
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init 方法执行");
	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		//打印:线程的ID,    request.getRemoteAddr():客户端的IP
		//线程的ID不一样,底层支持多线程  this的值一样:大家访问的是同一个Servlet
		System.out.println(Thread.currentThread().getId()+" "+request.getRemoteAddr()+"  "+request.getRemoteHost()+this+"   service方法执行。。。");
		//多个浏览器  访问 服务器， 这里 this是同一个。即当前的servlet只创建一个。不是每来一个浏览器请求，就创建一个servlet
		PrintWriter out = response.getWriter();
		out.println("message send from server");
	
	}

	@Override
	public void destroy() {
		System.out.println("destroy 方法执行");
	}
	
	@Override
	public ServletConfig getServletConfig() {
		return null;
	}
	
	@Override
	public String getServletInfo() {
		return null;
	}

}
