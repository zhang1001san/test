package com.it.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ServletDemo01 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("get方式请求");
	}

	/**
	 * 这个方法可以获取表单通过post方式提交来的数据
	 * <form action="/day09/ServletDemo01" method="post">
			账号:<input type="text" name="username" /><br />
			密码:<input type="password" name="password" /><br />
			爱好:<input type="checkbox" name="hobby"  value="ymq"/>羽毛球
			<input type="checkbox" name="hobby" value="bpq"/>兵乓球
			<input type="checkbox" name="hobby" value="basketball" />篮球<br />
			<input type="submit" value="注册" id="sumbit"  />
		</form>
	 * 
	 * 通过表单的name来获取值，通过  name = username 可以获取输入的账号
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//通过request获取表单参数   参数: parameter  request:请求  response:响应
		//通过表单的name来获取值，通过  name = username 可以获取输入的账号
		
		//获取账号
		String username = request.getParameter("username");
		//获取密码
		String password = request.getParameter("password");
		//获取爱好  爱好不止一个，所以不用request.getParameter("password"); 这个方法
		String[] hobbies = request.getParameterValues("hobby");
		
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		System.out.println("爱好："+Arrays.toString(hobbies));
	
		
		System.out.println("========================================");
		
		//获取到一个map,map中存放了表单中的所有数据  key = name,value = {值1，值2}
		// name = username value = {"name"} name = "hobby" value ={篮球，排球}
		Map<String, String[]> map = request.getParameterMap();
		Set<String> keySet = map.keySet();
		for (String name : keySet) {
			String[] value = map.get(name);
			System.out.println(name+":"+Arrays.toString(value));
		}
		
		System.out.println("============================");
		
		//获取表单的所有的name
		Enumeration<String> enumeration = request.getParameterNames();
		while (enumeration.hasMoreElements()) {
			String name = (String) enumeration.nextElement();
			System.out.println(name);
		}
		
	}

}
