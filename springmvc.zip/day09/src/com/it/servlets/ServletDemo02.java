package com.it.servlets;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 读取配置文件-->web.xml 中的<init-param>
 * @author Administrator
 *
 */

public class ServletDemo02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	public void init(ServletConfig config) throws ServletException {
		/**
		 * 通过servletConfig获取web.xml中为当前servlet配置的参数信息
		 * 1.config.getInitParameterNames(); 获取所有name的参数信息，
		 *   <init-param>
    			<param-name>password</param-name>
    			<param-value>123456</param-value>
    		</init-param>
    		<init-param>
    			<param-name>username</param-name>
    			<param-value>root</param-value>
    		</init-param>
    		
    		这里的name = password  value =123456
    		
    		2. config.getInitParameter(name); 
    		
		 */
		Enumeration<String> initParameterNames = config.getInitParameterNames();
		while (initParameterNames.hasMoreElements()) {
			String name = (String) initParameterNames.nextElement();
			String value = config.getInitParameter(name);
			System.out.println(name+":"+value);
		}
		
		
		//config！=servletConfig 
		ServletConfig servletConfig = getServletConfig();
		System.out.println("config:"+config);
		System.out.println("servletConfig: "+servletConfig);
		System.out.println("config==servletConfig:"+(config==servletConfig));
	}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		ServletConfig servletConfig = getServletConfig();
		System.out.println("doget  servletConfig:"+servletConfig);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
