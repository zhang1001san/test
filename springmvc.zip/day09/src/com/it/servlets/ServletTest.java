package com.it.servlets;

import java.io.IOException;

import javax.servlet.ServletException;

public class ServletTest {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, ServletException, IOException {
		
		Class<?> clazz = Class.forName("com.it.servlets.MyFirstServlet");
		
		String name = clazz.getName();
		System.out.println(name);
		System.out.println(clazz.getMethods()[0].getName());
		
		
		MyFirstServlet myServlet = (MyFirstServlet)clazz.newInstance();
		myServlet.init(null);
		myServlet.service(null, null);
		myServlet.destroy();
		
		
	}

}
