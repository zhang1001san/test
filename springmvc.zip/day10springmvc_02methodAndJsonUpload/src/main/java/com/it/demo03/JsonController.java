package com.it.demo03;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.it.domain.User;

@Controller
@RequestMapping(value="/jsonController")
public class JsonController {
	
	
	/**
	 * @RequestBody：获取请求体内容，ajax发送的请求参数是json格式，后台通过@RequestBody注解直接把数据封装到User对象中
	 * @ResponseBody:把user对象封装为json数据，直接响应
	 * @param user
	 * @return
	 */
	@RequestMapping(value="/testJson")
	public @ResponseBody User testJson(@RequestBody User user){
		System.out.println("user:"+user);
		
		User jsonUser = new User();
		jsonUser.setUsername("哈哈哈");
		jsonUser.setAge(18);
		
		//@ResponseBody:把jsonUser对象封装为json数据，直接响应，
		//不用自己把jsonUser转换为json格式的数据，再通过输出流响应到浏览器
		return jsonUser;
	}

}
