package com.it.demo01;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * 控制器方法的返回值
 * 1.String
 * 2.void
 * 3.ModelAndView
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value="/method")
public class MethodController {
	
	
	/**
	 * 1.方法的返回值为String
	 * @return
	 */
	@RequestMapping(value="/feedbackString")
	public String feedbackString(){
		System.out.println("方法的返回值为String");
		//1.默认转发，使用视图解析器
		//return "success";
		
		//2.转发，不使用视图解析器
		//return "forward:/jsp/success.jsp";
		
		//3.重定向，不使用视图解析器
		return "redirect:/jsp/success.jsp";
	}
	
	/**
	 *2. 方法的返回值为void
	 * @throws Exception 
	 */
	@RequestMapping(value="/feedbackVoid")
	public void feedbackVoid(HttpServletRequest request,HttpServletResponse response) throws  Exception{
		System.out.println("方法的返回值为void");
		//1.转发
		//request.getRequestDispatcher("/jsp/success.jsp").forward(request, response);
		
		//2.重定向
		//response.sendRedirect(request.getContextPath()+"/jsp/success.jsp");
		
		//3.也可以通过response指定响应结果，例如响应json数据：
		//设置响应内容和编码
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print("哈哈");
	}
	
	/**
	 * 3.方法的返回值为ModelAndView
	 * ModelAndView可以同时添加到域对象中，并且可以转发
	 * @return
	 */
	@RequestMapping("/feedbackModelAndView")
	public ModelAndView feedbackModelAndView(){
		System.out.println("方法的返回值为ModelAndView...");
		ModelAndView modelAndView = new ModelAndView();
		//存储数据
		modelAndView.addObject("msg", "熊大");
		
		//设置要跳转的页面，底层执行视图解析器
		modelAndView.setViewName("success");
		return modelAndView;
	}

}
