package com.it.demo04;

import java.io.File;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping(value="/uploadController")
public class UploadController {
	
	/**
	 * 文件上传 
	 * @param username 表单的username
	 * @param uploadFile 表单要上传文件的name,两者要一致
	 * @param request	
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/upload")
	public String uploadFile(String username,MultipartFile uploadFile,HttpServletRequest request) throws Exception{
		System.out.println("username:"+username);
		//MultipartFile uploadFile 文件上传对象
		//文件要上传到的路径
		ServletContext servletContext = request.getSession().getServletContext();
		//获取要上传到的文件夹的路径
		String path = servletContext.getRealPath("/uploadFiles");
		//创建File对象，如果没有存在，就创建
		File file = new File(path);
		if(!file.exists()){
			file.mkdirs();
		}
		//获取要上传文件的名称
		String filename = uploadFile.getOriginalFilename();
		// 考虑问题：文件名称相同了，会覆盖，把文件的名称修改唯一名称
		String uuid = UUID.randomUUID().toString().replace("-", "").toUpperCase();
		//修改文件名称
		filename = uuid+"_"+filename;
		//真正上传
		uploadFile.transferTo(new File(file, filename));
		return "success";
	}
	
	
	
	
	/**
	 * 上传文件到别的服务器
	 * @param username
	 * @param uploadFile
	 * @return
	 */
	public String uploadFileToOtherService(String username,MultipartFile uploadFile){
		
		System.out.println("上传别的文件到别的服务器....");
		
		return "success";
	}

}
