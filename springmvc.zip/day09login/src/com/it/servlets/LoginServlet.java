package com.it.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.it.domain.User;
import com.it.service.UserService;

/**
 * 登录
 * 通过表单，把账号和密码传到服务器
 * 通过request获取账号和密码，
 * 然后把账号和密码封装成一个User对象
 * 然后通过数据库操作用没有这个账号和密码，
 * 	1.如果不存在，则返回null	 ---> 给浏览器返回  login fail 
 * 	2.如果存在，返回这个账号和密码封装的对象  --->给浏览器返回  login ok
 *
 * 
 * @author Administrator
 *
 */

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		UserService userService = new UserService();
		User loginUser;
		try {
			loginUser = userService.login(user);
			PrintWriter  writer= response.getWriter();
			if(loginUser!=null){
				writer.println("login ok"); //账号和密码匹配
			}else{
				writer.println("login fail");//账号和密码不匹配
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		
		
	}

}
