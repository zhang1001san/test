package com.it.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.it.domain.User;
import com.it.utils.C3P0Utils;

public class UserDao {

	public User login(User user) throws SQLException {
		//获取核心类
		QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
		String sql = "select * from tb_user where username = ? and password = ?";
		Object[] params = {user.getUsername(),user.getPassword()};
		
		return queryRunner.query(sql, new BeanHandler<User>(User.class), params);
	}

}
