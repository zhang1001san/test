package com.it.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class C3P0Utils {

	//没有参数的new ComboPooledDataSource(); 只加载默认配置
	private static ComboPooledDataSource dataSource = new ComboPooledDataSource();

	private static ThreadLocal<Connection> threadLocal = new ThreadLocal<Connection>();
	
	
	/**
	 * 返回数据源
	 * @return
	 */
	public static DataSource getDataSource(){
		return dataSource;
	}
	
	/**
	 * 返回Connection对象
	 * @return
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException{
		
		Connection connection = threadLocal.get();
		if(connection!=null){

			return connection;
		}
		connection = dataSource.getConnection();
		threadLocal.set(connection);
		return connection;
	}
	
	
	/**
	 * 解除当前线程和其connection对象的绑定
	 * 为什么需要解绑呢？
	 * 如果一个线程消亡了，但这个线程绑定的connection对象没有解除绑定，那么这个connection对象
	 * 就不能放回连接池给别的线程使用。那么导致连接池的可用的connection对象也来越少，
	 * 最后连接池没有connection对象了，其他线程就不能获取connection对象执行相应的数据库操作了！
	 * 
	 */
	public static void remove(){
		threadLocal.remove();
	}

	/**
	 * 关闭连接
	 * @param resultSet
	 * @param connction
	 * @param statement
	 */
	public static void close(ResultSet resultSet,Connection connction,Statement statement){
		if(resultSet!=null){
			try {
				resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(connction!=null){
			try {
				connction.close();//并不是真的关闭连接，而是把这个连接放回C3P0连接池
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(statement!=null){
			try {
				statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	

	
}
