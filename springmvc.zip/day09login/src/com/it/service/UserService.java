package com.it.service;

import java.sql.SQLException;

import com.it.dao.UserDao;
import com.it.domain.User;

public class UserService {

	public User login(User user) throws SQLException {
		UserDao userDao = new UserDao();
		return userDao.login(user);
	}

}
