package com.it.servlets;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import com.it.utils.DownLoadUtils;

/**
 * 实现文件下载
 * 
 *web-inf 下新建一个download文件夹。
 *一个下载界面 的  download.html.通过选择某个文件(这个文件在download文件夹下)，实现把选中到文件传到客户端(即浏览器)
 *
 *		 下载流程
		 1.获取待下载文件名称
		 2.获取待下载文件指定输入流
		 3.获取到输出流
		 4.浏览器弹出另存为对话框,设置本次响应内容类型
		 5.流对接(将输入流中的数据读取到通过输出流发送到浏览器端)
		 6.释放资源
 *
 *
 */

public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/**
		 * 下载流程
		 * 1.获取待下载文件名称
		 * 2.获取待下载文件指定输入流
		 * 3.获取到输出流
		 * 4.浏览器弹出另存为对话框,设置本次响应内容类型
		 * 5.流对接(将输入流中的数据读取到通过输出流发送到浏览器端)
		 * 6.释放资源
		 */
		
		
		//下载第一版
		//1.获取待下载文件名称
//		String filename = request.getParameter("filename");//download.html 传过来的name = filename
//		ServletContext servletContext = getServletContext();
		
		//2.获取待下载文件指定输入流
		//2.1请求下载文件的真实路径
//		String filePath = servletContext.getRealPath("/WEB-INF/download/"+filename);
		//2.2获取下载文件的输入流
//		FileInputStream fis = new FileInputStream(filePath);
		
		//3.获取到输出流
//		ServletOutputStream out = response.getOutputStream();
		
		// 4.浏览器弹出另存为对话框,设置本次响应内容类型
//		response.setHeader("Content-Disposition", "attachment;filename="+filename);
//		String mimeType = servletContext.getMimeType(filename);
//		response.setContentType(mimeType);
		
		//5.流对接(将输入流中的数据读取到通过输出流发送到浏览器端)
		
//		int len = 0;
//		byte[] bys = new byte[1024];
//		while((len = fis.read(bys))!=-1){
//			out.write(bys, 0, len);
//		}
		
		//6.释放资源
//		fis.close();
//		out.close();
		
		
		//下载第2版  使用IOUtils
		 //1.获取待下载文件名称
//		String filename = request.getParameter("filename");
		
		 //2.获取待下载文件指定输入流
//		ServletContext servletContext = getServletContext();
//		InputStream is = servletContext.getResourceAsStream("/WEB-INF/download/"+filename);

		//3.获取到输出流
//		ServletOutputStream outputStream = response.getOutputStream();
		
		 //4.浏览器弹出另存为对话框,设置本次响应内容类型
//		response.setHeader("Content-Disposition", "attachment;filename="+filename);
//		String mimeType = servletContext.getMimeType(filename);
//		response.setContentType(mimeType);
		
		//5.流对接(将输入流中的数据读取到通过输出流发送到浏览器端)
//		IOUtils.copy(is, outputStream);
		
		//6.释放资源
//		IOUtils.closeQuietly(is);
	
		
		
		/*
		 * 3.下载第3版  解决乱码问题
		 * 主要是浏览器地址传到服务器的中文乱码(get方式。请求行有中文，会乱码)和服务器响应到浏览器的响应头中文乱码
		 * 1.浏览器地址传到服务器的中文乱码(get方式。请求行有中文，会乱码)
		 * get请求行不支持中文：get http://localhost:8080/day10download/DownloadServlet?filename=哈哈.txt http/1.1
		 * 		浏览器地址：http://localhost:8080/day10download/DownloadServlet?filename=哈哈.txt
		 *		 其中filename = "哈哈.txt"
		 * 		 到服务器filename = "åå.txt"
		 * 
		 * 2.服务器响应到浏览器的响应头中文乱码
				浏览器弹出另存为对话框,设置本次响应内容类型
				当filename = 哈哈.txt 即中文时，浏览器得到的响应头是filename = "哈哈.txt"
				但是另存为对话框的文件名 为： ".txt"！丢掉了中文"哈哈"！
				response.setHeader("Content-Disposition", "attachment;filename="+filename);
				String mimeType = servletContext.getMimeType(filename);
				response.setContentType(mimeType);
		 * 
		 */
		//1.获取待下载文件名称
			
		String tempName = request.getParameter("filename");
			//解决浏览器地址传到服务器的中文乱码(get方式。请求行有中文，会乱码)
		String filename = new String(tempName.getBytes("iso-8859-1"),"utf-8");
		//2.获取待下载文件指定输入流
		ServletContext servletContext = getServletContext();
		InputStream is = servletContext.getResourceAsStream("/WEB-INF/download/"+filename);
		
		
		//3.获取到输出流
		ServletOutputStream outputStream = response.getOutputStream();
	
		//4.浏览器弹出另存为对话框,设置本次响应内容类型
		
		//解决服务器响应到浏览器的响应头中文乱码
		DownLoadUtils.setConentType(request, filename, response);
	
//		response.setHeader("Content-Disposition", "attachment;filename="+filename);
		String mimeType = servletContext.getMimeType(filename);
		response.setContentType(mimeType);
	
		
		//5.流对接(将输入流中的数据读取到通过输出流发送到浏览器端)
		IOUtils.copy(is, outputStream);
		
		//6.释放资源
		IOUtils.closeQuietly(is);
		
		
	}

}
