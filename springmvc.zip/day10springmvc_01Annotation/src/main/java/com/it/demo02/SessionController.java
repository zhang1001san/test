package com.it.demo02;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.it.domain.Account;

@Controller
@RequestMapping("/session")
@SessionAttributes(names={"msg","account"})  //把request域对象中msg=哈哈存到session域对象中
public class SessionController {
	
	
	/**
	 * SessionAttributes注解，使用在类上
		1. 作用：用于多次执行控制器方法间的参数共享
		2. 属性
		   1. value：指定存入属性的名称
		往session域对象中设置值
	 * @return
	 */
	@RequestMapping(value="/setAttribute.do")
	public String setAttribute(Model model){
		Account account = new Account();
		account.setUsername("张三");
		account.setAge(19);
		account.setMoney(2000d);
		//底层往request域对象中设置值
		model.addAttribute("msg", "哈哈");
		model.addAttribute("account", account);
		return "success";
	}
	
	/**
	 * 获取session域对象的数据
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/getAttribute.do")
	public String getAttribute(ModelMap map){
		String msg = (String) map.get("msg");
		Account account = (Account) map.get("account");
		System.out.println("msg:"+msg);
		System.out.println("account:"+account);
		return "success";
	}
	
	/**
	 * 删除全部session域对象的数据
	 * @param status
	 * @return
	 */
	@RequestMapping("/delAttribute.do")
	public String delAttribute(SessionStatus status){
//		删除全部session域对象的数据
		status.setComplete();
		return "success";
	}

}
