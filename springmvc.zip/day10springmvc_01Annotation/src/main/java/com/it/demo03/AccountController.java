package com.it.demo03;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * PathVaribale注解在rest风格url中的应用
 * 作用：
	用于绑定url中的占位符。例如：请求url中 /delete/{id}，这个{id}就是url占位符。
	url支持占位符是spring3.0之后加入的。是springmvc支持rest风格URL的一个重要标志。
属性：
	value：用于指定url中占位符名称。
	required：是否必须提供占位符。

 * @author Administrator
 *
 */

@Controller
@RequestMapping(value="/accountController")
public class AccountController {

	
	@RequestMapping(value="/account.do/{sid}",method=RequestMethod.GET)
	public String findUserById(@PathVariable(value="sid") String id){
		System.out.println("get方式:通过id查询用户...");
		System.out.println("id:"+id);
		return "success";
	}
	
	@RequestMapping(value="/account.do",method=RequestMethod.GET)
	public String findAll(){
		System.out.println("get方式:查询所有用户...");
		return "success";
	}
	
	/**
	 * 只接受post请求
	 * @return
	 */
	@RequestMapping(value="/account.do",method=RequestMethod.POST)
	public String save(){
		System.out.println("post方式：保存用户。。。");
		return "success";
	}
	
	/**
	 * 处理put方式提交的请求
	 * 
	 * 基于HiddentHttpMethodFilter的示例
	 * 作用：
			由于浏览器 form 表单只支持 GET 与 POST 请求，而DELETE、PUT 等 method 并不支持，Spring3.0 添加了一个过滤器，可以将浏览器请求改为指定的请求方式，发送给我们的控制器方法，使得支持 GET、POST、PUT 与DELETE 请求。
		使用方法：
			第一步：在web.xml中配置该过滤器。
			第二步：请求方式必须使用post请求。
			第三步：按照要求提供_method请求参数，该参数的取值就是我们需要的请求方式。
	 * @return
	 */
	@RequestMapping(value="/account.do",method=RequestMethod.PUT)
	public String update(HttpServletRequest request){
		String method = request.getMethod();
		System.out.println("请求方式:"+method);
		
		System.out.println("更新用户...");
		return "success";//因为转发只支持get/post方式，所以页面会报错！，但是程序能执行
	}
}
