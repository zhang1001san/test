package com.it.demo01;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.it.domain.Account;

@Controller
@RequestMapping(value="/annotation")

public class AnnotationController {
	
	
	/**
	 * ModelAttribute注解
		1. 作用
		   1. 出现在方法上：表示当前方法会在控制器方法执行前线执行。
		   2. 出现在参数上：获取指定的数据给参数赋值。
		2. 应用场景
		   1. 当提交表单数据不是完整的实体数据时，保证没有提交的字段使用数据库原来的数据。

	 * @param account
	 * @return
	 */
	@RequestMapping(value="/testModelAttribute.do")
	public String testModelAttribute(@ModelAttribute(value="account")Account account){
		System.out.println(account);
		return "success";
	}
	
	/**
	 * 第一种，ModelAttribute修饰的方法有返回值
	 * @ModelAttribute加载方法上，此方法先执行。。。
	 * @param username
	 */
//	@ModelAttribute
//	public Account showAccount(String username){
//		
//		//通过username模拟从数据库中查询指定username的Account账号
//		Account account = new Account();
//		account.setUsername(username);
//		account.setAge(18);//表单提交有这个数据，封装不上
//		account.setMoney(2000d);//表单没有提交这个数据，能封装上
//		System.out.println("showAccount："+account);
//		return account;
//	}
	
	/**
	 * 修饰的方法没有返回值
	 * @param username
	 */
	@ModelAttribute
	public void showAccount(String username,Map<String, Account> map){
		//通过username模拟从数据库中查询指定username的Account账号
		Account account = new Account();
		account.setUsername(username);
		account.setAge(18);//表单提交有这个数据，封装不上
		account.setMoney(2000d);//表单没有提交这个数据，能封装上
		System.out.println("showAccount："+account);	
		map.put("account", account);
	}
	
	
	
	
	

	
			

}
