package com.it.domain;

import java.io.Serializable;

/**
 * 账户实体类
 * @author Administrator
 *
 */
public class Account implements Serializable{

	private static final long serialVersionUID = 6772853937597897831L;
	
	private String username;
	private  Integer age;
	private  Double money;//金额
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	@Override
	public String toString() {
		return "Account [username=" + username + ", age=" + age + ", money=" + money + "]";
	}
	
	

}
