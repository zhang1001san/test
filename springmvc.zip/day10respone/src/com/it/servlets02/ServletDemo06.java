package com.it.servlets02;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 获取src路径下指定名称的配置信息
 * @author Administrator
 *
 */
public class ServletDemo06 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取src路径下指定名称的配置信息
		
		//1.获取ServletDemo06.class文件在内存中的字节码对象
		Class clazz  = this.getClass();
		
		//2.获取ServletDemo06.class对应的字节码加载器(即类加载器)
		//(jdk中有一类程序，专用于把各个class文件加载到内存)
		ClassLoader classLoader = clazz.getClassLoader();
		
		//3.专用于获取src下指定文件的输入流
		InputStream is = classLoader.getResourceAsStream("prop.properties");
		
		//4.通过输入流读取数据
		Properties prop = new Properties();
		prop.load(is);
		String root = prop.getProperty("root");
		String user = prop.getProperty("user");
		System.out.println("root = "+root);
		System.out.println("user = "+user);
	}

}