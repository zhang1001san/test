package com.it.servlets02;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
获取到当前项目下WEB.xml中全局的配置信息
  我们之前在WEB中是为Servlet配置过键值对的数据,这些数据只能在当前的Servlet中获取到,
   <init-param>
    	<param-name>username</param-name>
    	<param-value>root</param-value>
    </init-param>
  
  如果希望配置一些参数,这些数据可以在整个web项目的所有Servlet都可以获取到,
  此时我们可以为当前应用配置全局的参数信息.配置方式如下:

	<!-- 全局的配置参数:所有的Servlet都可以获取到的	
	     局部的Servlet配置参数:当前的Servlet可以获取到
	 -->
	<context-param>
	  <param-name>username</param-name>
	  <param-value>mary</param-value>
	</context-param>
	<context-param>
	  <param-name>password</param-name>
	  <param-value>1234</param-value>
	</context-param>

*
*/

public class ServletDemo07 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//获取到当前项目下WEB.xml中全局的配置信息
		ServletContext servletContext = getServletContext();
		String username = servletContext.getInitParameter("username");
		String password = servletContext.getInitParameter("password");
		System.out.println("username = "+username );
		System.out.println("password = "+ password);
		
		System.out.println("==============================");
		Enumeration<String> initParameterNames = servletContext.getInitParameterNames();
		while (initParameterNames.hasMoreElements()) {
			String name = (String) initParameterNames.nextElement();
			String value = servletContext.getInitParameter(name);
			System.out.println(name +" :" +value);
		}
		
	}

}