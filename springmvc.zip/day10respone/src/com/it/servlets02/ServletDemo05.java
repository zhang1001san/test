package com.it.servlets02;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * 	获取到WEB项目下指定资源
	WEB项目的运行位置和源码位置不在同一个位置,,有时候我们需要获取到WEB项目在
	运行过程中,指定资源的真实路径或者指定资源的输入流,此时可以通过ServletContext来获取?为什么可以获取到?因为ServletContext里存放了当前web项目的路径等信息.
	
	1.获取服务端指定目录下指定资源/目录的真实路径
	String realPath = ServletContext.getRealPath("/WEB-INF/conf/conf01.properties")

	2.获取服务端指定目录下指定文件的输入流对象
	InputStream is = ServletContext.getResourceAsStream("/WEB-INF/conf/conf01.properties")

 *
 */

public class ServletDemo05 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//1.获取服务端指定目录下指定资源/目录的真实路径(绝对路径)
		ServletContext servletContext = getServletContext();
		
		// 	    / 代表当前项目
		String realPath = servletContext.getRealPath("/WEB-INF/conf.properties");
		System.out.println(realPath);
		
		//2.获取服务端指定目录下指定文件的输入流对象
		InputStream is = servletContext.getResourceAsStream("/WEB-INF/conf.properties");
		
		//把数据读出来
		Properties prop = new Properties();//导入的是 java.util.Properties  包
		prop.load(is);
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		System.out.println("username = "+username);
		System.out.println("password = "+password);
		
		
		
	}

}