package com.it.servlets02;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 获取到文件的mime类型
	我们每次向客户端响应的内容类型可能是不一样的.在讲解HTTP协议那天,我们通过观察网络部分,
	发现如果本次响应的内容类型是一个HTML网页,那么在contentType消息头中对应的值是:text/html;
	如果如果本次响应的内容类型是一个css文件.有时候用户会下载我们服务端的不同资源,
	为了让浏览器更好的识别返回到客户端的内容类型,我们要设置一下本次响应的内容类型,
	但问题是:计算机业界各种类型的文件是很多的,我们怎么知道应该如何设置本次响应内容类型呢?就可以通过如下的API:
	
	String value=ServletContext.getMimeType("333.avi");
	ServletContext在tomcat/conf/web.xml中,根据文件后缀来查找本次响应内容是什么.

 *
 */
public class ServletDemo08 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//通过ServletContext获取到文件的mime类型
		ServletContext servletContext = getServletContext();
		String mimeType = servletContext.getMimeType("haha.avi");
		System.out.println(mimeType);//video/x-msvideo
		
		//设置本次响应的ContentType
		//本质就是在本次响应中设置了一对响应头ContentType：mimeType
		response.setContentType(mimeType);
		//浏览器得到的一对响应头：Content-Type:"video/x-msvideo"
	}

}