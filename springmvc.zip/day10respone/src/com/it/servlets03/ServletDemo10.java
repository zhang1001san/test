package com.it.servlets03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDemo10 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response控制响应体
		//向浏览器输出字符数据
		PrintWriter writer = response.getWriter();
		writer.println("message send from server");
		
		//向浏览器输出字节数据
		//ServletOutputStream outputStream = response.getOutputStream();
		
		
		/*
		 * 以上2个流是互斥的
		 * 一次只能出现一个流，PrintWriter或者ServletOutputStream，如果两个同时出现会报错
		 */

	}

}