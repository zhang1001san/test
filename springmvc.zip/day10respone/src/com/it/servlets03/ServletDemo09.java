package com.it.servlets03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 	HttpServletResponse对象的作用
	既然HttpServletResponse代表从服务端到客户端响应这个过程,
	而且结合协议我们知道HTTP协议响应包含三大块内容,分别是响应行,响应头,响应体.
	那么HttpServletResponse对象的最用就是:可以控制响应部分的三个部分
	1.Response控制响应行
	2.Response控制响应头
	3.response控制响应体

 * @author Administrator
 *
 */

public class ServletDemo09 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.Response控制响应行
		//控制响应头的状态码
		//response.setStatus(200);
		//response.setStatus(302);
//		response.setStatus(404);
//		response.setStatus(404,	" web page no found");
		//response.sendError(404, " web page no found");
		
		// 2.Response控制响应头
//		response.setHeader(name, value);
//		response.setDateHeader(name, date);
//		response.setIntHeader(name, value);
		//自定义响应头
		//response.setHeader("hahah", "2323");
		
		
		// 2.1实现重定向302+location,
		//response.setStatus(302);
		//response.setHeader("location", "https://www.baidu.com/");

		// 2.2一句话搞定 response.sendRedrect(”路径”);
		// response.sendRedirect("https://www.baidu.com/");

		// 2.3通过控制响应头实现定时刷新
		// response.setHeader("refresh", "5;url=https://www.baidu.com/");

		// 2.4让浏览器弹出另存为对话框
		// response.setHeader("Content-Disposition","attachment;filename=xx.zip");

		// 2.5设置本次响应内容类型
		// response.setHeader("content-type", "text/html");
		// response.setContentType("text/html");
		
//		String mimeType = getServletContext().getMimeType("hah.avi");
//		System.out.println(mimeType);
//		response.setContentType(mimeType);
		
		
		//往响应体输入中文
		response.setContentType("text/html;charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.println("服务器发来的消息！");
		
	}

}