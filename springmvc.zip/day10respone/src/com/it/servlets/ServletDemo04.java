package com.it.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDemo04 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/**
		 	ServletContext.removeAttribute(name);
			从ServletContext中的MAP通过键名移除对应的值
			
			测试ServletContext在多个Servlet之间共享数据
		         从ServletContext中移除数据
		 */
		
		ServletContext servletContext = getServletContext();
		servletContext.removeAttribute("username");
		System.out.println("ServletDemo04  中 servletContext ="+servletContext);
		
	}

}