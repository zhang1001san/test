package com.it.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/**
		 * 获取ServletContext对象,通过断点形式可以查看ServletContxt中封装的数据
			通过观察得知:
			SevletContext中已经存放了很多键值对的数据
		 *		1.全局的WEB.xml+当前WEB的web.xml
		 *		2.当前WEB绝对路径 
		 * 		3.当前WEB运行需要的各种JAR包的路径(tomcat/lib ,jdk下相关jar)

		 */
		
		//获取ServletContext ,一个web项目只有一个ServletContext,
		//并且只创建一次。除非把服务器tomcat关了，重新再启动
		ServletContext servletContext01 = getServletContext();
		ServletContext servletContext02 = getServletContext();
		
		//测试ServletContext是否唯一
		System.out.println(servletContext01);
		System.out.println(servletContext02);
		System.out.println(servletContext01==servletContext02);
		
	}

}