package com.it.servlets;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDemo03 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/**
			ServletContext.getAttribute(name);
			从ServletContext中的MAP获取数据,通过键名获取对应的值: 返回类型为Object
			ServletContext.getAttributeNames();
			从ServletContext中的MAP获取MAP中所有的键名,返回一个枚举类型
		 */
		
		//测试向ServletContext 读取数据
		ServletContext servletContext = getServletContext();
		String username = (String)servletContext.getAttribute("username");
		String password = (String)servletContext.getAttribute("password");
		System.out.println("username = "+username);
		System.out.println("password = "+password);
		System.out.println("ServletDemo03  中 servletContext ="+servletContext);
		
		System.out.println("=====================================");
		//获取全部的servletContext 的attribute 的map中的所有的name
		Enumeration<String> attributeNames = servletContext.getAttributeNames();
		while (attributeNames.hasMoreElements()) {
			String name = (String) attributeNames.nextElement();
			System.out.println(name);
			//Object value = servletContext.getAttribute(name);
			//System.out.println(name+" :" +value);
			
		}
		
		
		
		
	}

}