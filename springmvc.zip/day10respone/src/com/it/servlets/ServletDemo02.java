package com.it.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
		 多个Servlet之间共享数据  attribute:属性
		由于一个WEB应用只有一个ServletContext对象,当我们在访问服务端的Servlet时,都可以在Servlet中获取到当前应用唯一的ServletContext对象,所以可以利用ServletContext对象来实现共享数据.
		ServletContext.setAttribute(name, object);
		向ServletContext中的MAP设置键值对的数据:键名是字符串类型,值为Object类型
		ServletContext.getAttribute(name);
		从ServletContext中的MAP获取数据,通过键名获取对应的值: 返回类型为Object
		ServletContext.getAttributeNames();
		从ServletContext中的MAP获取MAP中所有的键名,返回一个枚举类型
		ServletContext.removeAttribute(name);
		从ServletContext中的MAP通过键名移除对应的值
		
		tomcat停止后，再次运行，前一个通过
		ServletContext.setAttribute(name, object);方法添加的Attribute会消失
		
		思路：
		(1)ServletDemo02 添加attribute	：ServletContext.setAttribute(name, object)
		(2)ServletDemo03查看ServletDemo02添加的attribute：  ServletContext.getAttribute(name);
		(3)ServletDemo04删除attribute  ：ServletContext.removeAttribute(name);
		(4)在通过ServletDemo03查看ServletDemo04删除的attribute
		

 *
 */



public class ServletDemo02 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/**
		 * ServletContext.setAttribute(name, object);
		 * 向ServletContext中的MAP设置键值对的数据:键名是字符串类型,值为Object类型
		 * 
		 * 测试向servletContext存入数据
		 */
		
		ServletContext servletContext = getServletContext();
		servletContext.setAttribute("username", "root");
		servletContext.setAttribute("password", "123456");
		
		System.out.println("ServletDemo02  中 servletContext ="+servletContext);
		
	}

}