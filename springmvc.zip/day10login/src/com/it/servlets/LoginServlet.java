package com.it.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.it.domain.User;
import com.it.service.UserService;

/**
 * 登录
 * 通过表单，把账号和密码传到服务器
 * 通过request获取账号和密码，
 * 然后把账号和密码封装成一个User对象
 * 然后通过数据库操作用没有这个账号和密码，
 * 	1.如果不存在，则返回null	 ---> 给浏览器返回  login fail 
 * 	2.如果存在，返回这个账号和密码封装的对象  --->给浏览器返回  login ok
 *
 * 
 * 记录用户登录成功次数
 * 
 * @author Administrator
 *
 */

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }
    
    @Override
    public void init() throws ServletException {
    	super.init();
    	//这个servlet 一初始化添加一个attribute到servletContext中，记录用户成功登录的次数
    	ServletContext servletContext = getServletContext();
    	servletContext.setAttribute("count", 0);//自动装箱  int i = 0 -> Integer i =new Integer(0);
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		UserService userService = new UserService();
		User loginUser;
		try {
			loginUser = userService.login(user);
			PrintWriter  writer= response.getWriter();
			if(loginUser!=null){
				 //账号和密码匹配
				//把登录成功次数  +1
				ServletContext servletContext = getServletContext();
				Integer count = (Integer)servletContext.getAttribute("count");
				count++;
				servletContext.setAttribute("count", count);
				
				//从定向到项目下的CountServlet
				//设置本次响应的状态码为 302 ，设置本次响应头 location=/day10prelogin/CountServlet
				response.sendRedirect("/day10login/CountServlet");
				
				
				
			}else{
				writer.println("login fail");//账号和密码不匹配
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		
		
	}

}
