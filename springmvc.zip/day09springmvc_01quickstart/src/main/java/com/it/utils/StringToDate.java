package com.it.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;

/**
 * 字符串转换为日期格式
 *String 转换为Date
 * @author Administrator
 *
 */
public class StringToDate implements Converter<String, Date>{

	/**
	 * 字符串转换为日期格式
	 */
	@Override
	public Date convert(String source) {
		SimpleDateFormat sdf = null;
		//字符串类型2018-8-17
		if(source.contains("-")){ 
			sdf= new SimpleDateFormat("yyyy-MM-dd");//日期格式
		}else{
			//字符串类型2018/8/17
			sdf = new SimpleDateFormat("yyyy/MM/dd");
		}
		
		try {
			 Date date = sdf.parse(source);
			 return date;
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
		
	}

}
