package com.it.domain;

import java.io.Serializable;

/**
 * 实体类
 * @author Administrator
 *
 */
public class Account implements Serializable{


	private static final long serialVersionUID = 3031055704416478257L;

	private String username;//与表单的name=username一致
	private String money;//与表单的name = money一致
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMoney() {
		return money;
	}
	public void setMoney(String money) {
		this.money = money;
	}
	@Override
	public String toString() {
		return "Account [username=" + username + ", money=" + money + "]";
	}
	

	
	
}
