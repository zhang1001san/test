package com.it.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 请求参数之集合类型数据的封装
 * 	具体看表单，使用SPEL表达式
 * @author Administrator
 *
 */
public class User implements Serializable{
	

	private static final long serialVersionUID = 4885322089000212516L;

	private String name;
	private List<Account> accountList;//list类似数据的封装
	private Map<String, Account> accountMap;//map类型数据的封装
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	public Map<String, Account> getAccountMap() {
		return accountMap;
	}
	public void setAccountMap(Map<String, Account> accountMap) {
		this.accountMap = accountMap;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", accountList=" + accountList + ", accountMap=" + accountMap + "]";
	}
	

}
