package com.it.demo04;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/annotation")
public class AnnotationController {
	
	
	/**
	 * RequestHeader注解
		1. 作用：获取指定请求头的值
		2. 属性
		   1. value：请求头的名称
	 * @return
	 */
	@RequestMapping("/testRequestHeader.do")
	public String testRequestHeader(@RequestHeader(value="host")String header){
		System.out.println("host:"+header);
		return "suc";
	}
	
	/**
	 * CookieValue注解
		1. 作用：用于获取指定cookie的名称的值
		2. 属性
		   1. value：cookie的名称
	 * @return
	 */
	@RequestMapping("/testCookieValue.do")
	public String testCookieValue(@CookieValue(value="JSESSIONID")String cookieValue){
		//session对象一创建jsp就有，其id为jsessionid
		System.out.println("cookieValue:"+cookieValue);
		return "suc";
	}

}
