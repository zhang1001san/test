package com.it.demo03;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.domain.Account;
import com.it.domain.Student;
import com.it.domain.User;

/**
 * 请求参数的绑定
 * @author Administrator
 *
 */


@Controller	//把本类交给IOC容器管理
@RequestMapping("/account")//value可省略不写
public class AccountController {
	
	/**
	 * 请求参数的绑定之基本数据类型和字符串类型的绑定
	 * 		要求：提交表单的name和参数的名称是相同的
	 * @param username
	 * @param age
	 * @return
	 */
	@RequestMapping("/save.do")
	public String save(String username,Integer money){//表单的name = username ,name =age,否则username =null,money = null
		System.out.println("username:"+username);
		System.out.println("age :"+money);
		return "suc";//转发到/jsp/suc.jsp
	}
	
	/**
	 * 请求参数的绑定之实体类型（JavaBean）绑定
	 * 	即把请求参数封装成Javabean对象
	 * 要求：
	 * 	javabean对象的成员属性和表单的name一致，并提供set/get方法
	 * @param account
	 * @return
	 */
	@RequestMapping("/save2.do")
	public String saveDomain(Account account){
		System.out.println(account);
		return "suc";
	}
	
	
	/**
	 * 请求参数的绑定之集合数据类型（List、map集合等）绑定
	 * 	具体看表单demo3.jsp参数。
	 * @return
	 */
	@RequestMapping("/save3.do")
	public String saveCollection(User user){
		System.out.println(user);
		return "suc";
	}


	/**
	 * 解决表单名称和方法参数名称不一致问题
	 * 
	 *  RequestParam注解实现参数绑定
	 * 	作用:
	 * 		把请求中指定名称的参数给控制器中的形参赋值。
		属性：
			value：请求参数中的名称。
			required：请求参数中是否必须提供此参数。默认值：true。表示必须提供，如果不提供将报错。
	 * @param username
	 * @return
	 */
	@RequestMapping("/save4.do")
	public String save4(@RequestParam(name="name",required=false,defaultValue="呵呵")String username){
		System.out.println("username:"+username);
		return "suc";
	}
	
	
	/**
	 * 解决日期转换问题
	 * 解决方法
	 * 1.在Student 的birthday中添加注解@DateTimeFormat(pattern="yyyy-MM-dd")//日期格式
	 * 2.自定义类型转换器
	 * @param student
	 * @return
	 */
	@RequestMapping(value="/save5.do")
	public String saveDate(Student student){
		System.out.println(student);
		return "suc";
	}
	
	
	/**
	 * 使用ServletAPI对象作为方法参数
	 * SpringMVC还支持使用原始ServletAPI对象作为控制器方法的参数。支持原始ServletAPI对象有：
		HttpServletRequest 
		HttpServletResponse
		HttpSession
		java.security.Principal
		Locale
		InputStream 
		OutputStream 
		Reader 
		Writer
	 * @return
	 */
	@RequestMapping("/testServlet.do")
	public String testServlet(HttpServletRequest request,HttpServletResponse response,HttpSession session){
		System.out.println("request:"+request);
		System.out.println("response:"+response);
		System.out.println("session:"+session);
		HttpSession session2 = request.getSession();
		System.out.println("session2:"+session2);
		ServletContext servletContext = request.getSession().getServletContext();
		System.out.println("servletContext:"+servletContext);
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			System.out.println(cookie.getName()+"--"+cookie.getValue());
		}
		
		request.setAttribute("he", "mofashi");
		return "suc";
	}
}
