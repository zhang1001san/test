package com.it.demo01;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Springmvc框架的控制器对象，接收请求
 * @author Administrator
 *
 */
@Controller //把对象HelloController交给IOC容器管理
public class HelloController {

	
	@RequestMapping(value="/hello.do")
	public String beginSpringmvc(){
		System.out.println("hello Springmvc !!!");
		
		//跳转到suc.jsp页面，默认使用的是请求转发
//		return "/jsp/suc.jsp";
		
		//springmvc.xml中已经配置视图解析器viewResolver,定义了prefix和和suffix,
		//因此这里只需要转发要跳转jsp的名称即可
		return "suc";//即转发到/jsp/suc.jsp;
	}
}

