package com.it.demo02;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @RequestMapping的使用
 * 1.作用：
		用于建立请求URL和处理请求方法之间的对应关系。
   2.出现的位置
   		可以出现在类上(一级请求路径)和方法上(二级请求路径)
   3属性：
    	path		请求路径
 		value 		请求路径，path和value左右一样
 		method		当前方法只能被该请求方式所访问
 		params		请求中必须存在参数
 		header		请求中必须存在头信息
		
		value：用于指定请求的URL。它和path属性的作用是一样的。
		method：用于指定请求的方式。
		params：用于指定限制请求参数的条件。它支持简单的表达式。要求请求参数的key和value必须和配置的一模一样。
				例如：
					params = {"accountName"}，表示请求参数必须有accountName
					params = {"moeny!100"}，表示请求参数中money不能是100。
		headers：用于指定限制请求消息头的条件。
		注意：
			以上四个属性只要出现2个或以上时，他们的关系是与的关系。
 * @author Administrator
 *
 */
@RequestMapping(path="/user") //一级请求路径
@Controller
public class UserController {
	
	/**
	 * 请求路径: /项目名称/user/find.do
	 */
	@RequestMapping(path="/find.do")//二级请求路径
	public String find(){
		System.out.println("查询用户...");
		return "suc";//转发到 /jsp/suc.jsp
	}
	
	/**
	 * method=RequestMethod.GET 方法只支持get方式请求
	 * 		如果使用post请求，会报错。405 – Method Not Allowed
	 *params：用于指定限制请求参数的条件。它支持简单的表达式。
	 *			要求请求参数的key和value必须和配置的一模一样。如果不是，
	 *			会报错。400 – Bad Request
	 *以下在浏览器输入
	 *http://localhost:8080/day09springmvc_01quickstart/user/save.do?username=abc&money>1000
	 * @return
	 */
	@RequestMapping(value="/save.do",method=RequestMethod.GET,params={"username=abc","money>1000"},headers="host")
	public String save(){
		System.out.println("保存用户...");
		return "suc";
	}

}
