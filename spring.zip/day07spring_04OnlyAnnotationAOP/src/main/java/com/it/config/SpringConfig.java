package com.it.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 配置类
 * @author Administrator
 *
 */
@Configuration  //声明该类为配置类
//开启注解扫描      扫描指定包结构 <context:component-scan base-package="cn.it"/>
@ComponentScan(basePackages="com.it")
@EnableAspectJAutoProxy  //打开注解AOP的开关
public class SpringConfig {

}
