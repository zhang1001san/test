package com.it.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.it.domain.Account;
import com.it.service.AccountService;

public class AccountTest {
	
	
	/**
	 * 测试查询所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.获取对象
		//自动找到AccountService的实现类，只有AccountService的实现类添加@Service
		AccountService accountService = ac.getBean(AccountService.class);
		
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	
	/**
	 * 测试通过id查询账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountById() throws Exception{
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.获取对象
		//自动找到AccountService的实现类，只有AccountService的实现类添加@Service
		AccountService accountService = ac.getBean(AccountService.class);
		Account account = accountService.findAccountById(2);
		System.out.println(account);
	}
	
	
	/**
	 * 测试添加账号
	 * @throws Exception 
	 */
	@Test
	public void testInsertAccount() throws Exception{
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.获取对象
		//自动找到AccountService的实现类，只有AccountService的实现类添加@Service
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(5000d);
		accountService.insertAccount(account);
	}
	
	
	/**
	 * 测试修改账号
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccount() throws Exception{
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.获取对象
		//自动找到AccountService的实现类，只有AccountService的实现类添加@Service
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		Account account = new Account();
		account.setName("光头强");
		account.setMoney(10000d);
		account.setId(5);
		accountService.updateAccount(account);
		
	}
	
	/**
	 * 测试通过id删除账号
	 * @throws Exception 
	 */
	@Test
	public void testDeleteAccountById() throws Exception{
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.获取对象
		//自动找到AccountService的实现类，只有AccountService的实现类添加@Service
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		accountService.deleteAccountById(5);
	}

}
