package com.it.config;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration //声明为配置类
@ComponentScan(basePackages="com.it")//开启注解扫描
@PropertySource(value ="classpath:db.properties")//读取配置文件
public class SpringConfig {

	
	@Value("${jdbc.driver}")
	private String drive;
	
	@Value("${jdbc.url}")
	private String url;
	
	@Value("${jdbc.user}")
	private String  user ;
	
	@Value("${jdbc.password}")
	private String password;
	
	/**
	 * 创建连接池，并把连接池对象存入IOC容器中
	 * @return
	 * @throws Exception
	 */
	@Bean(name="dataSource")
	public DataSource createDataSource() throws Exception{
		//1.创建连接池
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		//2.设置属性
		dataSource.setDriverClass(drive);
		dataSource.setJdbcUrl(url);
		dataSource.setUser(user);
		dataSource.setPassword(password);
		
		return dataSource;
	}

	/**
	 * 创建QueryRunner，存入IOC容器中
	 * @param dataSource
	 * @return
	 */
	@Bean(name="queryRunner")
	@Resource(name="dataSource")//通过方法参数把IOC容器的dataSource对象注入到QueryRunner
	public QueryRunner createQueryRunner(DataSource dataSource ){
		return new QueryRunner(dataSource);
	}
	
}
