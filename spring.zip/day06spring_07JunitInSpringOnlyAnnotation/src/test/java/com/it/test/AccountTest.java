package com.it.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.config.SpringConfig;
import com.it.domain.Account;
import com.it.service.AccountService;

/**
 * Spring整合单元测试（纯注解方式）
 * @author Administrator
 *
 */
//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(value = SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=SpringConfig.class)//加载配置类
public class AccountTest {
	
	@Autowired
	private AccountService accountService;//自动类型注入
	
	

	/**
	 * 测试查询所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{

		
		/**
		 * Spring整合单元测试（纯注解方式），不需要每个测试方法都加载配置类，通过
		 * 自动注入accountService即可
		 */
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	/**
	 * 测试通过id查找账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountById() throws Exception{

		Account account = accountService.findAccountById(3);
		System.out.println(account);
		
	}
	
	
	/**
	 * 测试添加账号
	 * @throws Exception 
	 */
	@Test
	public void testInsertAccount() throws Exception{

		Account account = new Account();
		account.setName("熊大");
		account.setMoney(800d);
		accountService.insertAccount(account);
	}
	
	
	/**
	 * 测试修改账号
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccount() throws Exception{
		

		Account account = new Account();
		account.setId(4);
		account.setName("哈哈");
		account.setMoney(8888d);
		accountService.updateAccount(account);
	}

	
	/**
	 * 测试通过id删除账号
	 * @throws Exception 
	 */
	@Test
	public void testDeleteAccount() throws Exception{

		accountService.deleteAccount(4);
	}
}
