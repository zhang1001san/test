package com.it.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.domain.Account;
import com.it.service.AccountService;
/**
 * Spring框架整合JUnit单元测试（使用的junit4.12的版本）
 * 1. 为了简化了JUnit的测试，使用Spring框架也可以整合测试
   2. 具体步骤
		要求：必须先有JUnit的环境（默认会使用Eclipse导入单元测试的环境）！！
	
		步骤一：在程序中引入:spring-test.jar
		步骤二：在具体的测试类上添加注解
 * @author Administrator
 *
 */

//使用SpringJUnit4ClassRunner对象运行测试的方法
@RunWith(value = SpringJUnit4ClassRunner.class)
//SpringJUnit4ClassRunner运行过程中加载applicationContext.xml文件
@ContextConfiguration("classpath:applicationContext.xml")//一定要写classpath

public class AccountTest {
	
	@Autowired   //从IOC容器中获取对象
	private AccountService accountService;
	
	/**
	 * 测试查询所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{

		/**
		 * 不需要每次测试方法都要读取配置文件，Spring框架整合JUnit单元测试
		 */
		
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	
	/**
	 * 测试通过id查询账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountById() throws Exception{

		Account account = accountService.findAccountById(2);
		System.out.println(account);
	}
	
	
	/**
	 * 测试添加账号
	 * @throws Exception 
	 */
	@Test
	public void testInsertAccount() throws Exception{

		//3.调用方法
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(5000d);
		accountService.insertAccount(account);
	}
	
	
	/**
	 * 测试修改账号
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccount() throws Exception{

		//3.调用方法
		Account account = new Account();
		account.setName("光头强");
		account.setMoney(10000d);
		account.setId(4);
		accountService.updateAccount(account);
		
	}
	
	/**
	 * 测试通过id删除账号
	 * @throws Exception 
	 */
	@Test
	public void testDeleteAccountById() throws Exception{

		//3.调用方法
		accountService.deleteAccountById(4);
	}

}
