package com.it.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.domain.Account;
import com.it.service.AccountService;

/**
 * 通过配置文件方式使用JdbcTemplate
 * 以下增删改查方法都是使用JdbcTemplate完成，而不是dbUtils
 * @author Administrator
 *
 */
//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value="classpath:applicationContext.xml")//加载配置文件
public class AccountTest2 {
	
	@Autowired   //自动类型注入
	private AccountService accountService;
	
	/**
	 * 测试添加账号
	 */
	@Test
	public void testInsertAccount(){
		Account account = new Account();
		account.setName("熊二");
		account.setMoney(1500d);
		accountService.insertAccount(account);
	}
	
	/**
	 * 测试修改账号
	 */
	@Test
	public void testUpdateAccount(){
		
		Account account = new Account();
		account.setId(12);
		account.setName("光头强");
		account.setMoney(2000d);
		accountService.updateAccount(account);
	}
	
	/**
	 * 测试删除账号
	 */
	@Test
	public void testDeleteAccount(){
		accountService.deleteAccount(12);
	}
	
	/**
	 * 测试查询所有账号
	 */
	@Test
	public void testFindAllAccount(){
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	
	/**
	 * 测试通过id查询账号
	 */
	@Test
	public void testFindAccountById(){
		Account account = accountService.findAccountById(4);
		System.out.println(account);
	}
	
	/**
	 * 测试
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询所有账号
	 */
	@Test
	public void testFindAllAccountWithRowMapper(){
		List<Account> list = accountService.findAllAccountWithRowMapper();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	/**
	 * 测试
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询某个id账号
	 */
	@Test
	public void testFindAccountByIdWithRowMapper(){
		Account account = accountService.findAccountByIdWithRowMapper(3);
		System.out.println(account);
	}

	/**
	 * 查询聚合函数
	 * 查询总记录数
	 */
	@Test
	public void testFindTotalRecords(){
		Integer totalRecords = accountService.findTotalRecords();
		System.out.println("总记录数为:"+totalRecords);
	}
}
