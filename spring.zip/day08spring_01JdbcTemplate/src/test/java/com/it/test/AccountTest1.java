package com.it.test;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import com.it.domain.Account;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class AccountTest1 {
	
	
	/**
	 * 使用new 的方法创建JdbcTemplate
	 * 使用c3po连接池
	 * @throws Exception 
	 */
	@Test
	public void testJdbcTemplate1() throws Exception{
		
		//创建JdbcTemplate方式一：由template.setDataSource(dataSource)可以通过set方式注入dataSource
//		JdbcTemplate template = new JdbcTemplate();
//		template.setDataSource(dataSource);
		
		//创建JdbcTemplate方式二：可以通过构造方法注入
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		dataSource.setDriverClass("com.mysql.jdbc.Driver");
		dataSource.setJdbcUrl("jdbc:mysql:///spring_day02");
		dataSource.setUser("root");
		dataSource.setPassword("root");
		
		JdbcTemplate template = new JdbcTemplate(dataSource);
		//1.调用模板方法，和dbUtils类似
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(1500d);
		
		String sql ="insert into account values(null,?,?)";
		template.update(sql, account.getName(),account.getMoney());
		
		
	}
	
	/**
	 * 使用new 方式创建JdbcTemplate
	 * 使用dbcp连接池
	 */
	@Test
	public void testJdbcTemplate2(){
		
		//创建dbcp连接池
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql:///spring_day02");
		dataSource.setUsername("root");
		dataSource.setPassword("root");
		
		JdbcTemplate template = new JdbcTemplate(dataSource);
		//1.调用模板方法，和dbUtils类似
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(1500d);
		
		String sql ="insert into account values(null,?,?)";
		template.update(sql, account.getName(),account.getMoney());
	}

}
