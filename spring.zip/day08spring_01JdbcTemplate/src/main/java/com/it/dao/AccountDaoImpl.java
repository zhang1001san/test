package com.it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.it.domain.Account;

public class AccountDaoImpl implements AccountDao {

	private JdbcTemplate jdbcTemplate ;//通过配置文件注入
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	/**
	 * 添加账号
	 */
	@Override
	public void insertAccount(Account account) {
		String sql = "insert into account values(null,?,?)";
		jdbcTemplate.update(sql, account.getName(),account.getMoney());
	}

	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) {
		String sql = "update account set name =?,money = ? where id = ?";
		Object[] params = {account.getName(),account.getMoney(),account.getId()};
		jdbcTemplate.update(sql, params);
	}

	/**
	 * 删除账号
	 */
	@Override
	public void deleteAccount(Integer id) {
		String sql = "delete from account where id = ?";
		jdbcTemplate.update(sql, id);
	}

	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount() {
		String sql = "select * from account";
		List<Account> list = jdbcTemplate.queryForList(sql, Account.class);
		return list;
	}

	/**
	 * 通过id查询账号
	 */
	@Override
	public Account findAccountById(Integer id) {
		String sql = "select * from account where id = ?";
		Account account = jdbcTemplate.queryForObject(sql, Account.class, id);
		return account;
	}


	/**
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询所有账号
	 */
	@Override
	public List<Account> findAllAccountWithRowMapper() {
		String sql = "select * from account";
		List<Account> list = jdbcTemplate.query(sql, new AccountRowMapper());
		return list;
	}

	/**
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询某个id账号
	 */
	@Override
	public Account findAccountByIdWithRowMapper(Integer id) {
		String sql = "select * from account where id = ?";
		Account account = jdbcTemplate.queryForObject(sql, new AccountRowMapper(), id);
		return account;
	}


	/**
	 * 查询聚合函数
	 * 查询总记录数
	 */
	@Override
	public Integer findTotalRecords() {
		String sql = "select count(*) from account";
		Integer totalRecords = jdbcTemplate.queryForObject(sql, Integer.class);
		return totalRecords;
	}

	

}


/**
 * 通过RowMapper建立数据库字段和Account成员属性一一映射.可以解决数据库字段和Account属性名不同问题
 * @author Administrator
 *
 */
class AccountRowMapper implements RowMapper<Account>{

	/**
	 *用来进行数据封装
	 *一行一行数据进行封装
	 *ResultSet 结果集对象，存储一行数据
	 *rowNum 行号
	 */
	@Override
	public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
		Account account = new Account();
		account.setId(rs.getInt("id"));//这个id是数据库字段名
		account.setName(rs.getString("name"));
		account.setMoney(rs.getDouble("money"));
		return account;
	}
	
}


