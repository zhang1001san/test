package com.it.service;

import java.util.List;

import com.it.domain.Account;

public interface AccountService {
	
	public void insertAccount(Account account);
	
	public void updateAccount(Account account);
	
	public void deleteAccount(Integer id);
	
	public List<Account> findAllAccount();
	
	public Account findAccountById(Integer id);
	
	public List<Account> findAllAccountWithRowMapper();
	
	public Account findAccountByIdWithRowMapper(Integer id);
	
	public Integer findTotalRecords();

}
