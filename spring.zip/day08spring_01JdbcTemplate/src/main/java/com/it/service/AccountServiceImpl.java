package com.it.service;

import java.util.List;

import com.it.dao.AccountDao;
import com.it.domain.Account;

public class AccountServiceImpl implements AccountService {

	private AccountDao accountDao;//通过配置文件方式注入
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	/**
	 * 添加账号
	 */
	@Override
	public void insertAccount(Account account) {
		accountDao.insertAccount(account);
	}

	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) {
		accountDao.updateAccount(account);
	}

	/**
	 * 删除账号
	 */
	@Override
	public void deleteAccount(Integer id) {
		accountDao.deleteAccount(id);
	}

	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount() {
		return accountDao.findAllAccount();
	}

	/**
	 * 通过id查询账号
	 */
	@Override
	public Account findAccountById(Integer id) {
		return accountDao.findAccountById(id);
	}

	/**
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询所有账号
	 */
	@Override
	public List<Account> findAllAccountWithRowMapper() {
		return accountDao.findAllAccountWithRowMapper();
	}

	/**
	 * 通过RowMapper建立数据库字段和Account成员属性一一映射查询某个id账号
	 */
	@Override
	public Account findAccountByIdWithRowMapper(Integer id) {
		return accountDao.findAccountByIdWithRowMapper(id);
	}

	/**
	 * 查询聚合函数
	 * 查询总记录数
	 */
	@Override
	public Integer findTotalRecords() {
		return accountDao.findTotalRecords();
	}

}
