package com.it.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.domain.Account;
import com.it.service.AccountService;

public class AccountTest {
	
	
	
	/**
	 * 查询所有账号,使用Spring框架
	 * @throws Exception
	 */
	@Test
	public void testFindAllAccount() throws Exception{
	
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		//AccountService  accountService = (AccountService) ac.getBean("accountService");
		
		//也是可以的
		AccountService accountService = ac.getBean("accountService", AccountService.class);
		
		//3.调用方法
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
		
	}
	
	
	/**
	 * 测试通过id查找账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountById() throws Exception{
		//1.创建工厂，读取配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		AccountService accountService = (AccountService) ac.getBean("accountService");
		//3.调用方法
		Account account = accountService.findAccountById(3);
		System.out.println(account);
	}
	
	/**
	 * 测试添加账号
	 * @throws Exception 
	 */
	@Test
	public void testInsertAccount() throws Exception{
		//1.创建工厂，读取配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		AccountService accountService = (AccountService) ac.getBean("accountService");
		//3.调用方法
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(1000d);
		accountService.insertAccount(account);
	}
	
	
	/**
	 * 测试修改账号
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccount() throws Exception{
		//1.创建工厂，读取配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		AccountService accountService = (AccountService) ac.getBean("accountService");
		//3.调用方法
		Account account = new Account();
		account.setId(4);
		account.setName("熊二");
		account.setMoney(2000d);
		accountService.updateAccount(account);
	}
	
	/**
	 * 测试删除账号
	 * @throws Exception 
	 */
	@Test
	public void testDeleteAccount() throws Exception{
		//1.创建工厂，读取配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		AccountService accountService = (AccountService) ac.getBean("accountService");
		//3.调用方法
		accountService.deleteAccount(4);
	}
	
	
	/**
	 * 查询所有账号,没有使用Spring框架
	 * @throws Exception 
	 */
//	@Test
//	public void testFindAllAccount() throws Exception{
//		
//		AccountService accountService = new AccountServiceImpl();
//		List<Account> list = accountService.findAllAccount();
//		for (Account account : list) {
//			System.out.println(account);
//		}
//	}
	

	

}
