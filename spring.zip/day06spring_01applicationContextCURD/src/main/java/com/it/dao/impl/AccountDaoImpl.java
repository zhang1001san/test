package com.it.dao.impl;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.it.dao.AccountDao;
import com.it.domain.Account;

public class AccountDaoImpl implements AccountDao {

	private QueryRunner queryRunner;//通过配置文件注入
	

	public void setQueryRunner(QueryRunner queryRunner) {
		this.queryRunner = queryRunner;
	}

	/**
	 * 查询所有账号，使用spring框架
	 */
	@Override
	public List<Account> findAllAccount() throws Exception {
		
		String sql ="select * from account";
		return queryRunner.query(sql, new BeanListHandler<Account>(Account.class));
	}

	/**
	 * 通过id查找账号
	 */
	@Override
	public Account findAccountById(Integer id) throws Exception {
		String sql = "select * from account where id = ?";
		return queryRunner.query(sql, new BeanHandler<Account>(Account.class),id);
	}

	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) throws Exception {
		String sql = "update account set name=?,money=? where id=? ";
		Object[] params = {account.getName(),account.getMoney(),account.getId()};
		queryRunner.update(sql, params);
	}

	/**
	 * 删除账号
	 */
	@Override
	public void deleteAccount(Integer id) throws Exception {
		String sql = "delete from account where id = ?";
		queryRunner.update(sql, id);
	}

	/**
	 * 添加账号
	 * @param account
	 * @throws Exception
	 */
	@Override
	public void insertAccount(Account account) throws Exception {
		String sql = "insert into account values(null,?,?)";
		queryRunner.update(sql, account.getName(),account.getMoney());
	}

	/**
	 * 查询所有账号，没有使用Spring框架
	 * @throws Exception 
	 */
//	@Override
//	public List<Account> findAllAccount() throws Exception {
//		//1.创建连接池
//		ComboPooledDataSource dataSource = new ComboPooledDataSource();
//		//2.设置属性
//		dataSource.setDriverClass("com.mysql.jdbc.Driver");
//		dataSource.setJdbcUrl("jdbc:mysql:///spring_day02");
//		dataSource.setUser("root");
//		dataSource.setPassword("root");
//		
//		QueryRunner queryRunner = new QueryRunner(dataSource);
//		String sql = "select * from account ";
//		return queryRunner.query(sql, new BeanListHandler<Account>(Account.class));
//	}

}
