package com.it.service.impl;

import java.util.List;

import com.it.dao.AccountDao;
import com.it.domain.Account;
import com.it.service.AccountService;

public class AccountServiceImpl implements AccountService {

	//private AccountDao accountDao = new AccountDaoImpl();
	private AccountDao accountDao;//通过配置文件的方式注入数据
	
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	
	/**
	 * 查找所有账号
	 * @throws Exception 
	 */
	@Override
	public List<Account> findAllAccount() throws Exception {
		
		return accountDao.findAllAccount();
	}


	/**
	 * 通过id查找账号
	 * @throws Exception 
	 */
	@Override
	public Account findAccountById(Integer id) throws Exception {
		return accountDao.findAccountById(id);
	}


	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) throws Exception {
		accountDao.updateAccount(account);
	}


	/**
	 * 删除账号
	 */
	@Override
	public void deleteAccount(Integer id) throws Exception {
		accountDao.deleteAccount(id);
	}

	/**
	 * 添加账号
	 */
	@Override
	public void insertAccount(Account account) throws Exception {
		accountDao.insertAccount(account);
	}

}
