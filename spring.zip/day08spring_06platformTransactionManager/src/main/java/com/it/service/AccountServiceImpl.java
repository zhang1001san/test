package com.it.service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

public class AccountServiceImpl implements AccountService {

	private AccountDao accountDao; //通过配置文件注入
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}


	/**
	 * 转账(没有加事务)
	 * outAccount 转出账号
	 * inAccount 转入账号
	 * transferMoney 转账金额
	 */
	@Override
	public void transfer(Account outAccount, Account inAccount, Double transferMoney) {
		//并没有加事务处理
		//转出
		accountDao.updateAccount(outAccount, -transferMoney);
		//模拟异常
		//int i = 10/0;
		
		//转入
		accountDao.updateAccount(inAccount, transferMoney);
	}



}
