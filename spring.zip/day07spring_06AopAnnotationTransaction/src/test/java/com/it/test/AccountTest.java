package com.it.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.domain.Account;
import com.it.service.AccountService;

//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value="classpath:applicationContext.xml")//加载配置文件
public class AccountTest {
	
	@Autowired
	private AccountService accountService;
	
	
	/**
	 * 测试转账
	 * @throws Exception 
	 */
	@Test
	public void testTransfer() throws Exception{
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		accountService.transfer(account1, account2, 200d);
	
	}
	
	@Test
	public void testTransferByRound() throws Exception{

		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		accountService.transferByRound(account1, account2, 100d);
	}

}
