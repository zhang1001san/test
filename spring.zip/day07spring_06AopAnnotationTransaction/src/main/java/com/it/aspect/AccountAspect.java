package com.it.aspect;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.it.utils.C3P0Util;

/**
 * 切面类
 * @author Administrator
 *
 */
@Component //把该类存入IOC容器中
@Aspect //声明本类为切面类

public class AccountAspect {
	
	
	/**
	 * 空方法，定义通用切入点表达式
	 */
	@Pointcut(value="execution(* com.it.service.AccountServiceImpl.transfer(..))")
	public void pc(){
		
	}
	
	/**
	 * 开启事务,使用切入点表达式
	 */
	@Before(value="pc()")
	public void beforeMethod(){
		System.out.println("开启事务");
		C3P0Util.startTransaction();
	}
	
	/**
	 * 提交事务 在@afer中提交
	 */
	@AfterReturning(value="pc()")
	public void aferReturningMethod(){
		System.out.println("提交事务");
		C3P0Util.commit();
	}
	
	/**
	 * 回滚事务
	 */
	@AfterThrowing(value="pc()")
	public void aferThrowingMethod(){
		System.out.println("回滚事务");
		C3P0Util.rollback();
	}
	
	/**
	 * 释放资源
	 * aop注解的执行顺序为
	 * 1.没有异常
	 * 		@round @before  method   @round  @after @aferReturning
	 * 		因为@after 比@aferReturning执行的顺序早，如果在@after中释放资源，那么在@aferReturning中提交事务就会失败！
	 * 2.有异常
	 * 	@round @before  method   @round  @after @aferThrowing
	 */
	@After(value="pc()")
	public void aferMethod(){
		System.out.println("释放资源");

			C3P0Util.close();
	}
	
	/**
	 * 环绕通知
	 * 包含以上方法
	 */
	@Around(value="execution(* com.it.service.AccountServiceImpl.transferByRound(..))")
	public void round(ProceedingJoinPoint pp){
		
		try {
			//开启事务
			C3P0Util.startTransaction();
			//继续执行原先的代码，如这里的转账
			pp.proceed();
			//提交事务
			C3P0Util.commit();
		} catch (Throwable e) {
			//回滚事务
			C3P0Util.rollback();
			e.printStackTrace();
		}finally{
			//释放资源
			C3P0Util.close();
		}
		
	}

}
