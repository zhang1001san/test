package com.it.dao;

import org.apache.commons.dbutils.QueryRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;
import com.it.utils.C3P0Util;

@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired
	private QueryRunner queryRunner;//自动类型注入
	


	/**
	 * 转入转出
	 * transferMoney:转账金额，金额为正数，表示转入，金额为负数，表示转出
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) throws Exception {
		String sql = "update account set money=money+? where id =?";
		queryRunner.update(C3P0Util.getConnection(), sql, transferMoney,account.getId());
	}

}
