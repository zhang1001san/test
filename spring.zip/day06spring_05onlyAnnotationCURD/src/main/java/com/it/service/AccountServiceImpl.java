package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired  //自动类型注入，自动找到AccountDao实现类注入
	private AccountDao accountDao;
	
	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount() throws Exception {
		return accountDao.findAllAccount();
	}

	/**
	 * 通过id查找账号
	 */
	@Override
	public Account findAccountById(Integer id) throws Exception {
		return accountDao.findAccountById(id);
	}

	/**
	 * 添加账号
	 */
	@Override
	public void insertAccount(Account account) throws Exception {
		accountDao.insertAccount(account);
	}

	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) throws Exception {
		accountDao.updateAccount(account);
	}

	/**
	 * 通过id删除账号
	 */
	@Override
	public void deleteAccount(Integer id) throws Exception {
		accountDao.deleteAccount(id);
	}

}
