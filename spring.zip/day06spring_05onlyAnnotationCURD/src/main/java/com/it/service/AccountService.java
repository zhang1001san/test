package com.it.service;

import java.util.List;

import com.it.domain.Account;

public interface AccountService {
	
	public List<Account> findAllAccount()throws Exception;
	
	public Account findAccountById(Integer id)throws Exception;
	
	public void insertAccount(Account account)throws Exception;
	
	public void updateAccount(Account account)throws Exception;
	
	public void deleteAccount(Integer id)throws Exception;

}
