package com.it.dao;

import java.util.List;

import com.it.domain.Account;

public interface AccountDao {

	List<Account> findAllAccount()throws Exception;

	Account findAccountById(Integer id)throws Exception;

	void insertAccount(Account account)throws Exception;

	void updateAccount(Account account)throws Exception;

	void deleteAccount(Integer id)throws Exception;

}
