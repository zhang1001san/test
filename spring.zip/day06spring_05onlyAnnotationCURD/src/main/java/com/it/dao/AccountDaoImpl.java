package com.it.dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;

@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired  //自动类型注入
	private QueryRunner queryRunner;
	
	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount() throws Exception {
		String sql = "select * from account";
		return queryRunner.query(sql, new BeanListHandler<Account>(Account.class));
	}

	/**
	 * 通过id查找账号
	 */
	@Override
	public Account findAccountById(Integer id) throws Exception {
		String sql = "select * from account where id = ?";
		return queryRunner.query(sql, new BeanHandler<Account>(Account.class), id);
	}

	/**
	 * 添加账号
	 */
	@Override
	public void insertAccount(Account account) throws Exception {
		String sql = "insert into account values(null,?,?)";
		queryRunner.update(sql, account.getName(),account.getMoney());
	}
	
	/**
	 * 修改账号
	 */
	@Override
	public void updateAccount(Account account) throws Exception {
		String sql = "update account set name =?,money=? where id = ?";
		Object[] params = {account.getName(),account.getMoney(),account.getId()};
		queryRunner.update(sql, params);
	}
	
	/**
	 * 通过id删除账号
	 */
	@Override
	public void deleteAccount(Integer id) throws Exception {
		String sql = "delete from account where id =?";
		queryRunner.update(sql, id);
	}

}
