package com.it.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.it.config.SpringConfig;
import com.it.domain.Account;
import com.it.service.AccountService;

/**
 * 纯注解方式测试
 * @author Administrator
 *
 */
public class AccountTest {
	
	

	/**
	 * 测试查询所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{
		//1.读取配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器中获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	/**
	 * 测试通过id查找账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountById() throws Exception{
		//1.读配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		Account account = accountService.findAccountById(3);
		System.out.println(account);
		
	}
	
	
	/**
	 * 测试添加账号
	 * @throws Exception 
	 */
	@Test
	public void testInsertAccount() throws Exception{
		//1.读配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器中获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		Account account = new Account();
		account.setName("熊大");
		account.setMoney(800d);
		accountService.insertAccount(account);
	}
	
	
	/**
	 * 测试修改账号
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccount() throws Exception{
		
		//1.读取配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器中获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		Account account = new Account();
		account.setId(4);
		account.setName("哈哈");
		account.setMoney(8888d);
		accountService.updateAccount(account);
	}

	
	/**
	 * 测试通过id删除账号
	 * @throws Exception 
	 */
	@Test
	public void testDeleteAccount() throws Exception{
		//1.读取配置类
		ApplicationContext ac =new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器中获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		accountService.deleteAccount(4);
	}
}
