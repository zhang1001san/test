package com.it.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.it.config.SpringConfig;
import com.it.domain.Account;
import com.it.service.AccountService;

public class AccountTest {
	
	
	/**
	 * 纯注解方式
	 * 
	 */
	@Test
	public void testSave(){
		//1.加载配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器中获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		accountService.save();
	}
	
	
	
	/**
	 * 纯注解方法，查询所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{
		//1.读取配置类
		ApplicationContext ac = new AnnotationConfigApplicationContext(SpringConfig.class);
		//2.从IOC容器获取对象
		AccountService accountService = ac.getBean(AccountService.class);
		//3.调用方法
		List<Account> list = accountService.findAllAccount();
		for (Account account : list) {
			System.out.println(account);
		}
	}
	
	
	

}
