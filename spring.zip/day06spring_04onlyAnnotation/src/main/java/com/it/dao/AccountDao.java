package com.it.dao;

import java.util.List;

import com.it.domain.Account;

public interface AccountDao {
	
	public void save();

	public List<Account> findAllAccount()throws Exception;

}
