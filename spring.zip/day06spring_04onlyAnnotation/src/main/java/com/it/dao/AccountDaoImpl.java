package com.it.dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;

@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired
	private QueryRunner queryRunner;
	
	
	@Override
	public void save() {
		System.out.println("持久层: save...");
	}

	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount() throws Exception {
		String sql = "select * from account";
		return queryRunner.query(sql, new BeanListHandler<Account>(Account.class));
	}

}
