package com.it.service;

import java.util.List;

import com.it.domain.Account;

public interface AccountService {
	
	public void save();
	
	public List<Account> findAllAccount() throws Exception;

}
