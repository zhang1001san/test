package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;//通过注解的方式注入数据,自动找到其实现类
	
	@Override
	public void save() {
		System.out.println("业务层:save....");
		accountDao.save();
	}

	/**
	 * 查询所有账号
	 */
	@Override
	public List<Account> findAllAccount()throws Exception{
		return accountDao.findAllAccount();
	}

}
