package com.it.config;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * Spring 框架的配置类 = ApplicationContext.xml
 * @author Administrator
 * 1.@Configuration
		作用：
			用于指定当前类是一个 spring 配置类，当创建容器时会从该类上加载注解。获取容器时需要使用
			AnnotationApplicationContext(有@Configuration 注解的类.class)。
		属性：
			value:用于指定配置类的字节码
 * 2.@PropertySource
 * 	用于加载.properties 文件中的配置。例如我们配置数据源时，可以把连接数据库的信息写到
		properties 配置文件中，就可以使用此注解指定 properties 配置文件的位置。
	属性：
		value[]：用于指定 properties 文件位置。如果是在类路径下，需要写上 classpath:
 *
 *3. @Import
 *	作用：
		用于导入其他配置类，在引入其他配置类时，可以不用再写@Configuration 注解。
		当然，写上也没问题。
	属性：
		value[]：用于指定其他配置类的字节码
 */
@Configuration //声明当前类是配置类
@ComponentScan(basePackages="com.it")//扫描指定包结构 <context:component-scan base-package="cn.it"/>
@PropertySource(value = "classpath:db.properties")// 读取属性文件
@Import(value=SpringConfig2.class) //导入其他配置
public class SpringConfig {
	
	@Value("${jdbc.driver}")
	private String driver;
	
	@Value("${jdbc.url}")
	private String url;
	
	@Value("${jdbc.user}")
	private String user;
	
	@Value("${jdbc.password}")
	private String password;
	
	
	/**
	 * 以下相当于
	 * 	<!-- 配置连接池 -->
		 	<bean id="dataSource" class="com.mchange.v2.c3p0.ComboPooledDataSource">
		 		<property name="driverClass" value="com.mysql.jdbc.Driver"></property>
		 		<property name="jdbcUrl" value="jdbc:mysql:///spring_day02"></property>
		 		<property name="user" value="root"></property>
		 		<property name="password" value="root"></property>
		 	</bean>
		 	
		@Bean
		作用：
			该注解只能写在方法上，表明使用此方法创建一个对象，并且放入 spring 容器。
		属性：
			name：给当前@Bean 注解方法创建的对象指定一个名称(即 bean 的 id）
			
			
		把连接池dataSource存到IOC容器中
	 * @return
	 * @throws Exception
	 */
	@Bean(name="dataSource")
	public DataSource createDataSource() throws Exception{
		//1.创建连接池
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		//2.设置属性
		//第一种方法
//		dataSource.setDriverClass("com.mysql.jdbc.Driver");
//		dataSource.setJdbcUrl("jdbc:mysql:///spring_day02");
//		dataSource.setUser("root");
//		dataSource.setPassword("root");
		
		//第二种方法：通过读取配置文件
		dataSource.setDriverClass(driver);
		dataSource.setJdbcUrl(url);
		dataSource.setUser(user);
		dataSource.setPassword(password);
		return dataSource;
	}
	
	
	/**
	 * 创建QueryRunner，并存入IOC容器中
	 * 
	 * 把连接池对象注入到QueryRunner对象中
	 * @param dataSource
	 * @return
	 */
	@Bean(name="queryRunner")
	@Resource(name="dataSource")// 该注解作用在方式，通过该方法的参数把dataSource对象注入进来
	public QueryRunner createQueryRunner(DataSource dataSource){
		
		return new QueryRunner(dataSource);
	}
	
	

}
