package com.it.config;

import org.springframework.context.annotation.Configuration;

/**
 * 配置配置类
 * @author Administrator
 *
 */
@Configuration // 被其他配置类，如SpringConfig引入了，那么@Configuration	可以不编写
public class SpringConfig2 {
	//编写的配置
}
