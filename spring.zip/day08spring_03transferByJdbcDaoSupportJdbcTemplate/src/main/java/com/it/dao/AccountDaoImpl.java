package com.it.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.it.domain.Account;

/**
 * dao类2种编写的方式
 * 		1. 定义成员模板类
 * 		2. dao类继承 JdbcDaoSupport类
 * 
 * JdbcDaoSupport 是spring 框架为我们提供的一个类，该类中定义了一个 JdbcTemplate 对象，我们可以
	直接获取使用，但是要想创建该对象，需要为其提供一个数据源
 * @author Administrator
 *
 */

public class AccountDaoImpl extends JdbcDaoSupport implements AccountDao {

	//父类JdbcDaoSupport有setJdbcTemplate方法，并且用final修饰
//	private JdbcTemplate  jdbcTemplate;//通过set方法从配置文件注入
//	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//		this.jdbcTemplate = jdbcTemplate;
//	}


	/**
	 *转入转出
	 *transferMoney为正数+，表示转入金额，
	 *transferMoney为负数-，表示转出金额
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) {
		String sql = "update account set money=money+? where id = ?";
//		jdbcTemplate.update(sql, transferMoney,account.getId());
		super.getJdbcTemplate().update(sql, transferMoney,account.getId());
	}



	

}






