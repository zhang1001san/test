package com.it.service;

public class UserServiceImpl implements UserService{

	@Override
	public void save() {
		//模拟异常
		//int i = 10/0;
		System.out.println("保存用户...");
	}

	@Override
	public void findUser() {
		//模拟异常
		//int i = 10/0;
		System.out.println("查找用户...");
	}

	@Override
	public String update(int money) {
		System.out.println("更新用户...money="+money);
		return "更新成功...";
	}

}
