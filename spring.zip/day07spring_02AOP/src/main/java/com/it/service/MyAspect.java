package com.it.service;

import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 切面类
 * @author Administrator
 *相关术语：
 *	1. Joinpoint(连接点)		-- 所谓连接点是指那些被拦截到的点。在spring中,这些点指的是方法,因为spring只支持方法类型的连接点
   	2. Pointcut(切入点)	-- 所谓切入点是指我们要对哪些Joinpoint进行拦截的定义
   	3. Advice(通知/增强)-- 所谓通知是指拦截到Joinpoint之后所要做的事情就是通知.通知分为前置通知,后置通知,异常通知,最终通知,环绕通知(切面要完成的功能)
	4. Introduction(引介)-- 引介是一种特殊的通知在不修改类代码的前提下, Introduction可以在运行期为类动态地添加一些方法或Field
	5. Target(目标对象)-- 代理的目标对象
	6. Weaving(织入)-- 是指把增强应用到目标对象来创建新的代理对象的过程
	7. Proxy（代理）-- 一个类被AOP织入增强后，就产生一个结果代理类
	8. Aspect(切面)-- 是切入点和通知的结合，以后咱们自己来编写和配置的

 *
 *
 *
 */
public class MyAspect {

	/**
	 * 通知,即增强的代码 
	 */
	public void beforeMethod(){
		System.out.println("前置通知代码........");//适合做开启事务
	}
	
	public void afterMethod(){
		System.out.println("最终通知代码.......");//适合做释放资源
	}
	
	public void afterReturningMethod(){
		System.out.println("后置通知代码.......");//适合做提交事务
	}
	
	public void afterThrowingMethod(){
		System.out.println("异常通知代码.......");//适合做事务回滚
	}
	
	/**
	 * 测试环绕通知
	 * @param pp
	 */
	public void roundMethod(ProceedingJoinPoint pp){
		try {
			System.out.println("前置通知代码........");//适合做开启事务
			pp.proceed();// 让目标对象的方法去执行 findUser()方法
			System.out.println("后置通知代码.......");//适合做提交事务
		} catch (Throwable e) {
			System.out.println("异常通知代码.......");//适合做事务回滚
			e.printStackTrace();
		}finally {
			System.out.println("最终通知代码.......");//适合做释放资源
		}
	}
}
