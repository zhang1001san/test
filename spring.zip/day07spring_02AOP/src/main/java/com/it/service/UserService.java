package com.it.service;

public interface UserService {
	
	public void save();
	
	public void findUser();
	
	public String update(int money);

}
