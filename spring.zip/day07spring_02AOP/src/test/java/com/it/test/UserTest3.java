package com.it.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.service.UserService;

/**
 * 测试通知
 * 	Advice( 通知/ 增强):
		所谓通知是指拦截到 Joinpoint 之后所要做的事情就是通知。
		通知的类型：前置通知,后置通知,异常通知,最终通知,环绕通知
 * @author Administrator
 *
 */
//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value="classpath:applicationContext3.xml")//加载配置文件
public class UserTest3 {

	@Autowired
	private UserService userService;
	
	/**
	 * 测试保存
	 */
	@Test
	public void testSave(){
		userService.save();
	}
	
	/**
	 * 测试环绕通知
	 */
	@Test
	public void testFindUser(){
		userService.findUser();
	}
}
