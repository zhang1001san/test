package com.it.service;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * 切面类
 * @author Administrator
 *基于注解的 AOP  配置
 */
@Component  //把类放到IOC容器中 。相当于<bean id="" class="cn.itcast.demo1.MyAnnoAspect">
@Aspect  //声明当前类为切面类  <aop:aspect ref="myAnnotationlAspect">
public class MyAnnotationAspect {

	/**
	 * 通知
	 * @Before = <aop:before method="log"
	 * 
	 * @Before(value="切入点表达式") == <aop:before method="log" pointcut="execution(public void cn.it.service.UserServiceImpl.save())"/>
	 */
	@Before(value="execution(* com.it.service.*.save(..))")
	public void beforeMethod(){
		System.out.println("前置通知代码........");//适合做开启事务
	}
	

	
	@AfterReturning(value="execution(* com.it.service.*.save(..))")
	public void afterReturningMethod(){
		System.out.println("后置通知代码.......");//适合做提交事务
	}
	
	@AfterThrowing(value="execution(* com.it.service.*.save(..))")
	public void afterThrowingMethod(){
		System.out.println("异常通知代码.......");//适合做事务回滚
	}
	
	@After(value="execution(* com.it.service.*.save(..))")
	public void afterMethod(){
		System.out.println("最终通知代码.......");//适合做释放资源.出现最终通知代码在后置通知和异常通知前这种情况是正常的
	}
	/**
	 * 测试环绕通知。引入
	 * @param pp
	 */
	//@Around(value="ex()")
	//@Around(value="MyAnnotationAspect.ex()")
	@Around(value="com.it.service.MyAnnotationAspect.ex()")
	public void roundMethod(ProceedingJoinPoint pp){
		try {
			System.out.println("前置通知代码........");//适合做开启事务
			pp.proceed();// 让目标对象的方法去执行 findUser()方法
			System.out.println("后置通知代码.......");//适合做提交事务
		} catch (Throwable e) {
			System.out.println("异常通知代码.......");//适合做事务回滚
			e.printStackTrace();
		}finally {
			System.out.println("最终通知代码.......");//适合做释放资源
		}
	}
	
	
	/**
	 *空方法。定义通用的切入点表达式 
	 */
	@Pointcut(value="execution(* com.it.service.*.findUser(..))")
	public void ex(){
		
	}
}
