package com.it.service;

public interface UserService {
	
	public void save();
	
	public void findUser();
	

}
