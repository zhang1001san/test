package com.it.service;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

	@Override
	public void save() {
		//模拟异常
		int i = 10/0;
		System.out.println("保存用户...");
	}

	@Override
	public void findUser() {
		//模拟异常
		//int i = 10/0;
		System.out.println("查找用户...");
	}



}
