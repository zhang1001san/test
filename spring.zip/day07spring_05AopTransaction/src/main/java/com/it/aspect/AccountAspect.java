package com.it.aspect;

import java.sql.SQLException;

import org.aspectj.lang.ProceedingJoinPoint;

import com.it.utils.C3P0Util;

/**
 * 切面类
 * @author Administrator
 *
 */
public class AccountAspect {
	
	
	/**
	 * 开启事务
	 */
	public void beforeMethod(){
		System.out.println("开启事务");
		C3P0Util.startTransaction();
	}
	
	/**
	 * 提交事务 在@afer中提交
	 */
	public void aferReturningMethod(){
		System.out.println("提交事务");
		C3P0Util.commit();
	}
	
	/**
	 * 回滚事务
	 */
	public void aferThrowingMethod(){
		System.out.println("回滚事务");
		C3P0Util.rollback();
	}
	
	/**
	 * 释放资源
	 * aop注解的执行顺序为
	 * 1.没有异常
	 * 		@round @before  method   @round  @after @aferReturning
	 * 		因为@after 比@aferReturning执行的顺序早，如果在@after中释放资源，那么在@aferReturning中提交事务就会失败！
	 * 2.有异常
	 * 	@round @before  method   @round  @after @aferThrowing
	 */
	public void aferMethod(){
		System.out.println("释放资源");

			C3P0Util.close();
	}
	
	/**
	 * 环绕通知
	 * 包含以上方法
	 */
	public void round(ProceedingJoinPoint pp){
		System.out.println("round");
		
		try {
			//开启事务
			C3P0Util.startTransaction();
			//继续执行原先的代码，如这里的转账
			pp.proceed();
			//提交事务
			C3P0Util.commit();
		} catch (Throwable e) {
			//回滚事务
			C3P0Util.rollback();
			e.printStackTrace();
		}finally{
			//释放资源
			C3P0Util.close();
		}
		
	}

}
