package com.it.dao;

import org.apache.commons.dbutils.QueryRunner;

import com.it.domain.Account;
import com.it.utils.C3P0Util;

public class AccountDaoImpl implements AccountDao {

	//通过配置文件注入
	private QueryRunner queryRunner;
	
	public void setQueryRunner(QueryRunner queryRunner) {
		this.queryRunner = queryRunner;
	}




	/**
	 * 转入转出
	 * transferMoney:转账金额，金额为正数，表示转入，金额为负数，表示转出
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) throws Exception {
		String sql = "update account set money=money+? where id =?";
		queryRunner.update(C3P0Util.getConnection(), sql, transferMoney,account.getId());
	}

}
