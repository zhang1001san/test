package com.it.dao;

import com.it.domain.Account;

public interface AccountDao {

	/**
	 * 转账 转入转出
	 * @param account	账号
	 * @param transferMoney	转账金额，金额为正数，表示转入，金额为负数，表示转出
	 * @throws Exception
	 */
	public void updateAccount(Account account ,Double transferMoney)throws Exception;
}
