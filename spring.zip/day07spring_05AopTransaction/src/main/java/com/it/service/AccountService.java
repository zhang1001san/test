package com.it.service;

import com.it.domain.Account;

public interface AccountService {

	/**
	 * 转账
	 * @param account1 	转账人
	 * @param account2	收账人
	 * @param transferMoney	转账金额
	 * @throws Exception 
	 */
	public void transfer(Account account1,Account account2,Double transferMoney) throws Exception;

	
	/**
	 * 转账:通过环绕通知方式增加事务代码
	 * @param account1 	转账人
	 * @param account2	收账人
	 * @param transferMoney	转账金额
	 * @throws Exception 
	 */
	public void transferByRound(Account account1,Account account2,Double transferMoney) throws Exception;
}
