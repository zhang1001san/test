package com.it.service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

public class AccountServiceImpl implements AccountService {

	private AccountDao accountDao;//通过配置文件注入
	
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}


	/**
	 * 转入转出
	 * @throws Exception 
	 * 
	 */
	@Override
	public void transfer(Account account1, Account account2, Double transferMoney) throws Exception {
		/**
		 * 通过aop 动态代理，为这个方法增加事务
		 * 转入转出要么一起成功，要么一起失败
		 */
		//转出
		accountDao.updateAccount(account1, -transferMoney);
		//转入
		accountDao.updateAccount(account2, transferMoney);
	}


	/**
	 * 转账
	 * 通过使用环绕通知的方法添加事务
	 */
	@Override
	public void transferByRound(Account account1, Account account2, Double transferMoney) throws Exception {
		/**
		 * 通过aop 动态代理，为这个方法增加事务
		 * 转入转出要么一起成功，要么一起失败
		 */
		//转出
		accountDao.updateAccount(account1, -transferMoney);
		
		//模拟异常
		//int i = 10/0;
		
		//转入
		accountDao.updateAccount(account2, transferMoney);
	}

}
