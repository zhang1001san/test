package com.it.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.domain.Account;
import com.it.service.AccountService;

public class AccountTest {
	
	
	
	/**
	 * 测试转账
	 * @throws Exception 
	 */
	@Test
	public void testTransfer() throws Exception{
		//1.加载配置文件
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.从IOC容器中获取对象
		AccountService accountService  = (AccountService) ac.getBean("accountService");
		
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		accountService.transfer(account1, account2, 200d);
	
	}
	
	@Test
	public void testTransferByRound() throws Exception{
		//1.加载配置文件
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.从IOC容器中获取对象
		AccountService accountService  = (AccountService) ac.getBean("accountService");
		
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		accountService.transferByRound(account1, account2, 100d);
	}

}
