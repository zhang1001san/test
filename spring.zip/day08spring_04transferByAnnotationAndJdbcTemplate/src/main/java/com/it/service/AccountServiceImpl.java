package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao; //自动类型注入


	/**
	 * 转账(没有加事务)
	 * outAccount 转出账号
	 * inAccount 转入账号
	 * transferMoney 转账金额
	 */
	@Override
	public void transfer(Account outAccount, Account inAccount, Double transferMoney) {
		//并没有加事务处理
		//转出
		accountDao.updateAccount(outAccount, -transferMoney);
		//转入
		accountDao.updateAccount(inAccount, transferMoney);
	}



}
