package com.it.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;

@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired
	private JdbcTemplate  jdbcTemplate;//自动类型注入


	/**
	 *转入转出
	 *transferMoney为正数+，表示转入金额，
	 *transferMoney为负数-，表示转出金额
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) {
		String sql = "update account set money=money+? where id = ?";
		jdbcTemplate.update(sql, transferMoney,account.getId());
	}



	

}






