package com.it.dao;

import com.it.domain.Account;

public interface AccountDao {
	
	public void updateAccount(Account account ,Double transferMoney);

}
