package com.it.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.it.domain.Account;

public class AccountDaoImpl implements AccountDao {

	private JdbcTemplate  jdbcTemplate;//通过set方法从配置文件注入
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	/**
	 *转入转出
	 *transferMoney为正数+，表示转入金额，
	 *transferMoney为负数-，表示转出金额
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) {
		String sql = "update account set money=money+? where id = ?";
		jdbcTemplate.update(sql, transferMoney,account.getId());
	}



	

}






