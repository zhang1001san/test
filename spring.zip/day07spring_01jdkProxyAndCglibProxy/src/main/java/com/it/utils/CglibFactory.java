package com.it.utils;

import java.lang.reflect.Method;

import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import com.it.service.MyService;


/**
 * cglib生成代理对象
 * @author Administrator
 *
 */
public class CglibFactory implements MethodInterceptor {

	private MyService myService;//要代理的对象
	
	public CglibFactory(MyService myService) {
		super();
		this.myService = myService;
	}

	/**
	 * 生成代理对象
	 * @return
	 */
	public  MyService createEnhanceMyService(){
		// 1.创建CGLIB核心的类
		Enhancer enhancer = new Enhancer();
		//2.设置父类
		enhancer.setSuperclass(MyService.class);
		//3.设置回调函数
		enhancer.setCallback(this);//其实是调用intercept()方法。CglibFactory 实现了 MethodInterceptor接口
		//4.生成代理对象
		MyService enhanceService = (MyService) enhancer.create();
		return enhanceService;
	}

	/**
	 * 回调函数
	 * @param obj 
	 * @param method	正在执行的方法
	 * @param args	方法参数
	 * @param methodProxy	
	 * @return
	 * @throws Throwable
	 */
	@Override
	public Object intercept(Object obj, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
		Object value = null;
		//给目标类，即MyService的转账方法增强
		if(method.getName().equals("transfer")){
			try {
				//增强代码
				System.out.println("开启事务....");
				//执行要代理对象原先的方法，如这里的转账
				//value =methodProxy.invoke(myService, args);
				value =methodProxy.invokeSuper(obj, args);
				//增强代码
				System.out.println("提交事务");
			} catch (Exception e) {
				//增强代码
				System.out.println("回滚事务...");
				e.printStackTrace();
			}
		}else{
			//不需要增强的方法，直接执行原先的方法就好
			//value =methodProxy.invoke(myService, args);
			value =methodProxy.invokeSuper(obj, args);
		}
		return value;
	}

}
