package com.it.utils;

import java.lang.reflect.Method;

import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import com.it.service.NoInterfaceAccountServiceImpl;


public class CglibProxy {
	
	
	
	/**
	 * 使用cglib动态代理对象
	 * @param obj
	 * @return 返回生成的代理对象
	 */
	public static Object getProxy(Object object){
		// 1.创建CGLIB核心的类
		Enhancer enhancer = new Enhancer();
		//2.设置父类
		enhancer.setSuperclass(object.getClass());
		//3.设置回调函数
		enhancer.setCallback(new MethodInterceptor() {
			@Override
			public Object intercept(Object obj, Method method, Object[] args,
					MethodProxy methodProxy) throws Throwable {
				
				//4.保存方法的返回值
				Object value =null;
				
				try {
					//5.开启事务
					C3P0Util.startTransaction();
					//6.执行要代理对象原先的方法，如这里的转账
					value = methodProxy.invokeSuper(obj, args);
					//7.提交事务
					C3P0Util.commit();
				} catch (Exception e) {
					//8.回滚事务
					C3P0Util.rollback();
					e.printStackTrace();
				}finally {
					//9.释放资源
					C3P0Util.close();
				}
				//10.返回方法执行的返回值
				return value;
			}
		});
		
		//11.生成代理对象
		return enhancer.create();
	}
	
	public static NoInterfaceAccountServiceImpl getProxy2(){
		// 1.创建CGLIB核心的类
		Enhancer enhancer = new Enhancer();
		//2.设置父类 cglib的原理是子类增强父类，即生成的代理对象是子类。其继承要增强的类(父类)，因而父类不能用final修饰
		//注：cglib生成的代理对象，不能使用注解。因为注解对于子类没有作用
		enhancer.setSuperclass(NoInterfaceAccountServiceImpl.class);
		//3.设置回调函数
		enhancer.setCallback(new MethodInterceptor() {
			@Override
			public Object intercept(Object obj, Method method, Object[] args,
					MethodProxy methodProxy) throws Throwable {
				
				//4.保存方法的返回值
				Object value =null;
				
				try {
					//5.开启事务
					C3P0Util.startTransaction();
					//6.执行要代理对象原先的方法，如这里的转账
					value = methodProxy.invokeSuper(obj, args);
					//7.提交事务
					C3P0Util.commit();
				} catch (Exception e) {
					//8.回滚事务
					C3P0Util.rollback();
					e.printStackTrace();
				}finally {
					//9.释放资源
					C3P0Util.close();
				}
				//10.返回方法执行的返回值
				return value;
			}
		});
		
		NoInterfaceAccountServiceImpl proxy = (NoInterfaceAccountServiceImpl)enhancer.create();
		return proxy;
		//11.生成代理对象
	}
	
	/**
	 *模板代码
	 */
//	public static OrderDaoImpl getProxy(){
//		// 创建CGLIB核心的类
//		Enhancer enhancer = new Enhancer();
//		// 设置父类
//		enhancer.setSuperclass(OrderDaoImpl.class);
//		// 设置回调函数
//		enhancer.setCallback(new MethodInterceptor() {
//			@Override
//			public Object intercept(Object obj, Method method, Object[] args,
//					MethodProxy methodProxy) throws Throwable {
//				if("save".equals(method.getName())){
//					// 记录日志
//					System.out.println("记录日志了...");
//				}
//				return methodProxy.invokeSuper(obj, args);
//			}
//		});
//		// 生成代理对象
//		OrderDaoImpl proxy = (OrderDaoImpl) enhancer.create();
//		return proxy;
//	}

}
