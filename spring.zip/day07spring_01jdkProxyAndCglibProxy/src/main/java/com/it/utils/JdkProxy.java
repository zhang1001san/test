package com.it.utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * 使用jdk方式实现动态代理
 * @author Administrator
 *
 */
public class JdkProxy {
	
	/**
	 * 创建代理对象
	 * 给要代理的对象的方法添加处理事务代码
	 * @param obj 要被代理的对象，必须要实现接口
	 * @return 代理对象
	 */
	public static  Object getProxy(Object obj){
		
		Object objProxy = Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), new InvocationHandler() {
			
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				//1.方法执行的返回值
				Object value = null;
				
				try {
					//2.开启事务
					C3P0Util.startTransaction();
					//3.执行对象原先的方法，比如这里的账号操作
					value = method.invoke(obj, args);
					
					//4.提交事务
					C3P0Util.commit();
				} catch (Exception e) {
					//5.回滚事务
					C3P0Util.rollback();
					e.printStackTrace();
				}finally {
					//6.释放资源
					C3P0Util.close();
				}
				//7.返回执行方法的返回值
				return value;
			}
		});
		
		//8.返回代理对象
		return objProxy;
	}

}
