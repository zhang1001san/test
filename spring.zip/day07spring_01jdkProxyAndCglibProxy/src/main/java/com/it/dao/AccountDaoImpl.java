package com.it.dao;

import org.apache.commons.dbutils.QueryRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;
import com.it.utils.C3P0Util;

@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired
	QueryRunner queryRunner;//通过配置文件实现注入

	@Override
	public void transferAccount(Account account, Double transferMoney) throws Exception {
		String sql = "update account set money=money+? where id = ?";
		queryRunner.update(C3P0Util.getConnection(), sql, transferMoney,account.getId());
	}
	
	
	

}
