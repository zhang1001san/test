package com.it.dao;

import com.it.domain.Account;

public interface AccountDao {


	/**
	 * 转账
	 * @param account 账号
	 * @param transferMoney	转账金额
	 * @throws Exception 
	 */
	public void transferAccount(Account account,Double transferMoney) throws Exception;

}
