package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;
import com.it.domain.Account;
import com.it.utils.C3P0Util;

@Service
public class AccountServiceImpl implements AccountService {
	
	
	@Autowired  //默认找到它的实现类，实现注入
	private AccountDao accountDao;


	/**
	 * 事务
	 * a1 给a2转账金额money
	 *  这个方法虽然处理事务，但是如果多个方法都需要使用事务，那么每个方法都需要添加处理事务
	 *  代码，这样程序代码太臃肿，考虑使用动态代理技术为需要处理事务的方法动态处理事务
	 */
	@Override
	public void transferAccount(Account account1, Account account2, Double transferMoney) {
		try {
			//1.开启事务
			C3P0Util.startTransaction();
			//2.执行转账操作，要么全部成功，要么全部失败
			accountDao.transferAccount(account1, -transferMoney);
		
			//模拟异常
			//int i = 10/0;
			
			accountDao.transferAccount(account2, transferMoney);
			
			//3.提交事务
			C3P0Util.commit();
			
		} catch (Exception e) {
			//4.回滚事务
			C3P0Util.rollback();
			e.printStackTrace();
		}finally {
			//5.释放资源
			C3P0Util.close();
		}
		
	}


	/**
	 * 转账
	 * 
	 * 使用动态代理技术为方法动态添加处理事务代码
	 * @throws Exception 
	 * 
	 */
	@Override
	public void transferAccountByJDKProxy(Account account1, Account account2, Double transferMoney) throws Exception {
		//转账，要么一起成功，要么一起失败
		accountDao.transferAccount(account1, -transferMoney);
		
		//模拟异常
		//int i = 10/0;
		
		accountDao.transferAccount(account2, transferMoney);
		
	}
	
	
	
	


}
