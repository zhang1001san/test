package com.it.service;


/**
 * 要被cglib增强的类，不能被final修饰，否则就不能继承
 * @author Administrator
 *
 */
public class MyService {
	
	

	public void transfer(){
		System.out.println("转账中....");
		//模拟异常
		//int i = 10/0;
	}
	
	public void updateAccount(){
		System.out.println("更新账户....");
	}

}
