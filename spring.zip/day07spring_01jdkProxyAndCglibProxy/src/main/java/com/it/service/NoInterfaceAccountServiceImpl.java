package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;
import com.it.domain.Account;

/**
 * 	1.基于接口的动态代理,如JDK proxy类
 * 		提供者：JDK 官方的 Proxy 类。
		要求：被代理类最少实现一个接口。
	2.基于子类的动态代理，如cglib
		提供者：第三方的 CGLib，如果报 asmxxxx 异常，需要导入 asm.jar。
		要求：被代理类不能用 final 修饰的类（最终类）。
 * 
 * 
 * 是实现类，不是接口
 * @author Administrator
 *
 */
@Service
public class NoInterfaceAccountServiceImpl {
	
	@Autowired  //默认找到它的实现类，实现注入
	public AccountDao accountDao;
	
	/**
	 * 转账，使用cglib动态代理技术
	 * @param account1 要转账的账号
	 * @param account2	收账的账号
	 * @param tranferMoney 转账金额
	 * @throws Exception 
	 */
	public void transferAccountByCglib(Account account1,Account account2,Double transferMoney) throws Exception{
		
		//转账，要么一起成功，要么一起失败，使用cglib动态代理
		accountDao.transferAccount(account1, -transferMoney);
		accountDao.transferAccount(account2, transferMoney);
	}

}
