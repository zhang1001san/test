package com.it.service;

import com.it.domain.Account;

public interface AccountService {
	
	/**
	 * 
	 * @param account1   转账的账号
	 * @param account2	收账人账号
	 * @param transferMoney 转账金额
	 */
	public void transferAccount(Account account1,Account account2,Double transferMoney);
	
	/**
	 * 处理转账
	 * 使用动态代理技术为需要处理事务的方法添加处理事务逻辑，不需要每个方法都添加处理事务逻辑
	 * 
	 * @param account1 转账的账号
	 * @param account2 收账人账号
	 * @param tranferMoney 转账金额
	 * @throws Exception 
	 */
	public void transferAccountByJDKProxy(Account account1,Account account2,Double transferMoney) throws Exception;

}
