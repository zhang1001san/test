package com.it.test;

import com.it.service.MyService;
import com.it.utils.CglibFactory;

public class CglibFactoryTest {
	
	
	public static void main(String[] args) {
		
		MyService myService= new MyService();
		//创建cglib代理工厂
		CglibFactory cglibFactory = new CglibFactory(myService);
		//通过工厂生产代理类
		MyService enhanceService = cglibFactory.createEnhanceMyService();
		enhanceService.transfer();
		
	}

}
