package com.it.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.domain.Account;
import com.it.service.AccountService;
import com.it.service.NoInterfaceAccountServiceImpl;
import com.it.utils.CglibProxy;
import com.it.utils.JdkProxy;

/**
 * Spring框架整合Junit
 * @author Administrator
 *
 */
//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value="classpath:applicationContext.xml")//加载配置文件
public class AccountTest {

	@Autowired
	private AccountService accountService;
	
	
	@Autowired    //自动类型注入
	private NoInterfaceAccountServiceImpl noInterfaceAccountServiceImpl;
	
	/**
	 * 测试转账
	 */
	@Test
	public void testTransferAccount(){
		
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		accountService.transferAccount(account1, account2, 100d);
	}
	
	/**
	 * 测试转账
	 * 使用动态代理技术为方法动态添加处理事务代码
	 * @throws Exception 
	 */
	@Test
	public void testTransferAccountByJDKProxy() throws Exception{
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		//创建代理对象
		AccountService accountServiceProxy = (AccountService) JdkProxy.getProxy(accountService);
		//使用代理对象
		accountServiceProxy.transferAccountByJDKProxy(account1, account2, 200d);
	}
	
	
	/**
	 * 使用cglib动态代理技术代理NoInterfaceAccountServiceImpl
	 * @throws Exception 
	 */
	@Test
	public void testTransferAccountByCglib() throws Exception{
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		
		//创建cglib动态代理对象
		 NoInterfaceAccountServiceImpl  proxy = (NoInterfaceAccountServiceImpl) CglibProxy.getProxy(noInterfaceAccountServiceImpl);
		 //调用方法
		 proxy.transferAccountByCglib(account1, account2, 300d);
	}
	@Test
	public void testTransferAccountByCglib2() throws Exception{
		Account account1 = new Account();
		account1.setId(4);
		Account account2 = new Account();
		account2.setId(5);
		
		NoInterfaceAccountServiceImpl proxy = CglibProxy.getProxy2();
		//调用方法
		proxy.transferAccountByCglib(account1, account2, 300d);
	}
	
}
