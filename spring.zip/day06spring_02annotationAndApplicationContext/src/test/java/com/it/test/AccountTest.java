package com.it.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.service.AccountService;

public class AccountTest {
	
	
	/**
	 * IOC 注解方式入门
	 * 测试保存
	 */
	@Test
	public void testSave(){
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		AccountService accountService = (AccountService) ac.getBean("accountService");
		accountService.save();
		System.out.println(accountService.show());
	}
	
	/**
	 * 1.测试注解@Scope
	 * 		修改AccountServiceImpl的
	 * 		@Scope("singleton")为@Scope("prototype"),
	 * 		看accountService1，accountService2是否一样
	 * 2.<bean id="" class="" init-method="" destroy-method="" />
	 *		 @PostConstruct:用于指定初始化方法。
	 *		 @PreDestroy:用于指定销毁方法
	 * 查看日记的 时候，初始化方法打印的数据在上方，往上翻
	 */
	@Test
	public void testSave2(){
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		AccountService accountService1 = (AccountService) ac.getBean("accountService");
		AccountService accountService2 = (AccountService) ac.getBean("accountService");
		
		/**@Scope("singleton")
		 * singleton：两个地址一样
		 * prototype,两个地址不一样
		 */
		System.out.println(accountService1);
		System.out.println(accountService2);
		
		//销毁容器
		ClassPathXmlApplicationContext ca = (ClassPathXmlApplicationContext)ac;
		ca.close();
	}

}
