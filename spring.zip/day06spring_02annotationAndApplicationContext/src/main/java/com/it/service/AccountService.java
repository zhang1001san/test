package com.it.service;

public interface AccountService {

	public void save();
	
	public String show();
}
