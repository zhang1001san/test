package com.it.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.it.dao.AccountDao;

/**
 * @Component
 * 	作用：
		把资源让 spring 来管理。相当于在 xml 中配置一个 bean。
	属性：
		value：指定 bean 的 id。如果不指定 value 属性，默认 bean 的 id 是当前类的类名。首字母小写
 * 
 * @Controller @Service @Repository.这三个功能和用法和@Component一样
 * 他们三个注解都是针对一个的衍生注解，他们的作用及属性都是一模一样的。
	他们只不过是提供了更加明确的语义化。
	@Controller ：一般用于表现层的注解。
	@Service ：一般用于业务层的注解。
	@Repository ：一般用于持久层的注解。
	细节：如果注解中有且只有一个属性 要赋值时是 ，且名称是 value ，value 
 * 
 * 注解方式
 * 
 * @Component = <bean id="accountServiceImpl" class="com.it.service.AccountServiceImpl"></bean>
 * 
 * @Component("accountService") = <bean id="accountService" class="com.it.service.AccountServiceImpl"></bean>
 * 
 * 配置文件：必须提供属性的set方法
 * 	<bean id="accountService" class="com.it.service.AccountServiceImpl">
 * 		<property name="username" value="值">
 * </bean>
 * 
 * 注解方式：不提供属性的set方法
 * 	@Value(value="美美")
	private String username;
 * 
 * @author Administrator
 */
//@Component
//@Component("accountService")

@Service("accountService")
// 对象的作用范围，取值：singleton prototype request session globalsession
@Scope("singleton")
public class AccountServiceImpl implements AccountService {

	
	
	/**
	 * Value注解，给普通数据类型注入值（String Integer Double ）
	 */
	@Value(value="赵敏")//value可省略
	private String name;
	@Value("18")
	private Integer age;
	
	/**
	 * @Autowired		自动注入，默认是按类型注入，没有按名称注入  AccountDao accountDao = new AccountDaoImpl()
	 * @Autowired
	 * @Qualifier(value="ud")		两个注解一起使用，按名称注入的
	 * 
	 * @Resource(name="userDao") 是Java提供的注解，该注解被Spring的框架支持。一个注解相当于上述2个注解
	 */
	
	//第一种用法
//	@Autowired
//	private AccountDao accountDao;
	
	//第二种用法：两个注解一起使用，按名称注入
//	@Autowired
//	@Qualifier(value="ad")
//	private AccountDao accountDao;
	
	//第三种用法
	@Resource(name="ad")
	private AccountDao accountDao;
	
	
	@Override
	public void save() {
		System.out.println("业务层:保存...");
		accountDao.save();
	}
	
	/**
	 * <bean id="" class="" init-method="" destroy-method="" />
	 * @PostConstruct:用于指定初始化方法。
	 * @PreDestroy:用于指定销毁方法
	 */
	@PostConstruct
	public void init(){
		System.out.println("初始化....");
	}
	
	/**
	 * <bean id="" class="" init-method="" destroy-method="" />
	 * @PostConstruct:用于指定初始化方法。
	 * @PreDestroy:用于指定销毁方法
	 */
	@PreDestroy
	public void destroy(){
		System.out.println("销毁....");
	}
	
	
	@Override
	public String show() {
		return "AccountServiceImpl [name=" + name + ", age=" + age + "]";
	}


}
