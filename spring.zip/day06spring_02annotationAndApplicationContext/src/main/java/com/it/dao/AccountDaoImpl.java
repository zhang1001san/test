package com.it.dao;

import org.springframework.stereotype.Repository;

//@Repository
@Repository("ad")
public class AccountDaoImpl implements AccountDao {

	@Override
	public void save() {
		System.out.println("持久层:保存...");
	}

	
}
