package com.it.dao;

public interface AccountDao {

	void save();

}
