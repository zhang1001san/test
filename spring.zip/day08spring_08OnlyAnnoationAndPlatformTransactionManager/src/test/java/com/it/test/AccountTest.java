package com.it.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.it.config.SpringConfig;
import com.it.domain.Account;
import com.it.service.AccountService;

//使用SpringJUnit4ClassRunner对象运行测试方法
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=SpringConfig.class)//读取配置类
public class AccountTest {
	
	@Autowired
	private AccountService accountService;//自动类型注入
	
	
	/**
	 * 测试转账
	 */
	@Test
	public void testTransfer(){
		
		Account outAccount = new Account();
		outAccount.setId(4);
		Account inAccount = new Account();
		inAccount.setId(5);
		accountService.transfer(outAccount, inAccount, 100d);
	}

	
	/**
	 * 测试添加
	 */
	@Test
	public void testInsertAccount(){
		Account account1 = new Account();
		account1.setName("熊大");
		account1.setMoney(2000d);
		Account account2 = new Account();
		account2.setName("熊二");
		account2.setMoney(3000d);
		
		accountService.insertAccount(account1, account2);
	}
	
	
}
