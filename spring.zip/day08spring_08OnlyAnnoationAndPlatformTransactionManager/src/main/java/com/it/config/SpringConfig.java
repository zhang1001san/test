package com.it.config;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration //声明当前类为配置类
@ComponentScan(basePackages="com.it")//开启注解扫描
@PropertySource(value="classpath:db.properties")//加载数据库配置文件
@EnableTransactionManagement //开启事务注解开关
public class SpringConfig {

	@Value("${jdbc.driver}")
	private String drive;
	
	@Value("${jdbc.url}")
	private String url;
	
	@Value("${jdbc.user}")
	private String  user ;
	
	@Value("${jdbc.password}")
	private String password;
	
	/**
	 * 创建连接池，并把连接池对象存到IOC容器中
	 * @return
	 * @throws Exception
	 */
	@Bean(name="dataSource")
	public DataSource createDataSource() throws Exception{
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		//设置连接池属性
		dataSource.setDriverClass(drive);
		dataSource.setJdbcUrl(url);
		dataSource.setUser(user);
		dataSource.setPassword(password);
		
		System.out.println(drive);
		System.out.println(url);
		System.out.println(user);
		System.out.println(password);
		return dataSource;
	}
	
	/**
	 * 创建平台事务管理器，并放入IOC容器中
	 * @param dataSource
	 * @return
	 */
	@Resource(name="dataSource")//传入dataSource给方法做参数
	@Bean(name="transactionManager")//创建平台事务管理器，并放入IOC容器中
	public PlatformTransactionManager createPlatformTransactionManager(DataSource dataSource){
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
		return transactionManager;
	}
}
