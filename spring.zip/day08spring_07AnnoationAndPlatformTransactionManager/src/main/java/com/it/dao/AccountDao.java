package com.it.dao;

import com.it.domain.Account;

public interface AccountDao {
	
	public void updateAccount(Account account ,Double transferMoney);
	
	/**
	 * 添加账号
	 * @param account
	 */
	public void insertAccount(Account account);

}
