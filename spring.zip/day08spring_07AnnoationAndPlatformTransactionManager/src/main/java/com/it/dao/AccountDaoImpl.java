package com.it.dao;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.it.domain.Account;

/**
	通过注解的方式给父类JdbcDaoSupport注入DataSource
 * 
 * JdbcDaoSupport 是spring 框架为我们提供的一个类，该类中定义了一个 JdbcTemplate 对象，我们可以
	直接获取使用，但是要想创建该对象，需要为其提供一个数据源
 * @author Administrator
 *
 */

@Repository
public class AccountDaoImpl extends JdbcDaoSupport implements AccountDao {

	
	/**
	 * 通过注解的方式给父类JdbcDaoSupport注入DataSource
	 * @Resource(name="dataSource")
	 * 		1.可以用在给类的成员属性注入数据
	 * 		2.可以用在方法上，做方法的参数，即从IOC容器中获取dataSource，然后把dataSource当做方法参数调用方法
	 * 流程：
	 * 		1.applicationContext.xml中开启注解扫描，把扫描得到的DataSource存入IOC容器中
	 * 		2.当注解扫描到此@Resource(name="dataSource")此注解是，自动调用从IOC容器中获取dataSource，然后把dataSource
	 * 			当做setDataSourceForJdbcDaoSupport()的方法参数传入setDataSourceForJdbcDaoSupport().
	 * 			或者说， @Resource(name="dataSource")用在方法时，会自动调用相应的方法
	 * 
	 */
	@Resource(name="dataSource")
	public void setDataSourceForJdbcDaoSupport(DataSource dataSource){
		//调用父类JdbcDaoSupport的setDataSource()方法给父类的JdbcTemplate初始化
		System.out.println("调用父类JdbcDaoSupport的setDataSource()方法");
		super.setDataSource(dataSource);
	}
	

	/**
	 *转入转出
	 *transferMoney为正数+，表示转入金额，
	 *transferMoney为负数-，表示转出金额
	 */
	@Override
	public void updateAccount(Account account, Double transferMoney) {
		String sql = "update account set money=money+? where id = ?";
		super.getJdbcTemplate().update(sql, transferMoney,account.getId());
	}


	@Override
	public void insertAccount(Account account) {
		String sql = "insert into account values(null,?,?)";
		super.getJdbcTemplate().update(sql, account.getName(),account.getMoney());
	}



	

}






