package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.AccountDao;
import com.it.domain.Account;

/**
 * @Transactional 写在类上，对类的所有方法都加事务处理
 * @Transactional 写在某个方法上，只对该方法加事务处理
 * @author Administrator
 *
 */

@Service
//@Transactional  //有默认值
@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED,readOnly=false)
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao; 



	/**
	 * 转账(没有加事务)
	 * outAccount 转出账号
	 * inAccount 转入账号
	 * transferMoney 转账金额
	 */
	@Override
	//@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED,readOnly=false)
	public void transfer(Account outAccount, Account inAccount, Double transferMoney) {
		//并没有加事务处理
		//转出
		accountDao.updateAccount(outAccount, -transferMoney);
		//模拟事务
		//int i = 10/0;
		//转入
		accountDao.updateAccount(inAccount, transferMoney);
	}



	@Override
	public void insertAccount(Account account1, Account account2) {
		
		accountDao.insertAccount(account1);
		
		//模拟异常
		//int i =10/0;
		
		accountDao.insertAccount(account2);
		
		Account outAccount = new Account();
		outAccount.setId(4);
		Account inAccount = new Account();
		inAccount.setId(5);
		this.transfer(outAccount, inAccount, 200d);
		
	}







}
