package com.it.service;

import com.it.domain.Account;

public interface AccountService {
	
	/**
	 * 
	 * @param outAccount 转出账号
	 * @param inAccount	转入账号
	 * @param transferMoney  转账金额
	 */
	public void transfer(Account outAccount,Account inAccount ,Double transferMoney);
	
	
	/**
	 * 添加账号
	 * @param account
	 */
	public void insertAccount(Account account1,Account account2);

}
