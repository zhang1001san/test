package com.it.config;

import org.apache.commons.dbutils.QueryRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 配置类
 * @author Administrator
 *
 */
@Configuration	//声明当前类为配置类
@ComponentScan(basePackages="com.it")//注解扫描
@EnableAspectJAutoProxy   //打开aop注解开关
public class SpringConfig {
	
	
	
	/**
	 * 创建QueryRunner对象，并放入IOC容器中
	 * @return
	 * 
	 */
	@Bean
	public QueryRunner createQueryRunner(){
		
		return new QueryRunner();
	}

}
