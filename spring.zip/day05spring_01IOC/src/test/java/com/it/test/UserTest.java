package com.it.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.demo01.IUserService;
import com.it.demo01.UserServiceImpl;

public class UserTest {
	
	
	/**
	 * 从IOC容器中获取对象
	 * 
	 */
	@Test
	public void testSave1(){
		// 1.创建工厂中，解析配置文件，通过把类变成对象，存入IOC容器中，标准写法
//		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//可写成
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		// 2.通过id从工厂获取对象
		UserServiceImpl us = (UserServiceImpl)ac.getBean("us");
		//3.调用对象的方法
		us.save();
	}
	
	/**
	 * 面向接口编程，较好
	 * 从IOC容器获取对象
	 */
	@Test
	public void testSave2(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从工厂获取对象
		
		//面向接口编程，耦合性降低
		IUserService us =  (IUserService) ac.getBean("us");
		//3.调用对象的方法
		us.save();
	}
	
	/**
	 * BeanFactory 才是 Spring 容器中的顶层接口。
		ApplicationContext 是它的子接口。
		BeanFactory 和 ApplicationContext 的区别：
		创建对象的时间点不一样。
		ApplicationContext：只要一读取配置文件，默认情况下就会创建对象。
		BeanFactory：什么使用什么时候创建对象。
	 */
	@Test
	public void testSave3(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//ApplicationContext：只要一读取配置文件，默认情况下就会创建对象。
		//而不是到ac.getBean("us");才创建对象
		System.out.println("=======================");
		
		//2.通过id从工厂获取对象
		IUserService us  = (IUserService) ac.getBean("us");
		//3.调用方法
		us.save();
	}
	
	
	/**
	 * bean标签作用：
			用于配置对象让 spring 来创建的。
			默认情况下它调用的是类中的无参构造函数。如果没有无参构造函数则不能创建成功。
			属性：
			id：给对象在容器中提供一个唯一标识。用于获取对象。
			class：指定类的全限定类名。用于反射创建对象。默认情况下调用无参构造函数。
			scope：指定对象的作用范围。
				singleton :默认值，单例的.只创建一个对象
				prototype :多例的.每次调用	ac.getBean("us")获取对象，都会创建新的对象
				request  :WEB 项目中,Spring 创建一个 Bean 的对象,将对象存入到 request 域中.
				session  :WEB 项目中,Spring 创建一个 Bean 的对象,将对象存入到 session 域中.
				global session  :WEB 项目中,应用在 Portlet 环境.如果没有 Portlet 环境那么
									globalSession 相当于 session.
			init-method：指定类中的初始化方法名称。
			destroy-method：指定类中销毁方法名称。
			
	bean的作用范围和生命周期
	单例对象：scope="singleton"
		一个应用只有一个对象的实例。它的作用范围就是整个引用。
		生命周期：
			对象出生：当应用加载，创建容器时，对象就被创建了。
			对象活着：只要容器在，对象一直活着。
			对象死亡：当应用卸载，销毁容器时，对象就被销毁了。
	多例对象：scope="prototype"
			每次访问对象时，都会重新创建对象实例。
		生命周期：
		对象出生：当使用对象时，创建新的对象实例。
		对象活着：只要对象在使用中，就一直活着。
		对象死亡：当对象长时间不用时，被 java 的垃圾回收器回收了。

	 */
	@Test
	public void testSave4(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从工厂获取对象
		IUserService us1 = (IUserService) ac.getBean("us");
		//3.调用方法
		us1.save();
		
		IUserService us2 = (IUserService) ac.getBean("us");
		us2.save();
		
		/**
		 * 如果scope是prototype，那么us1和us2地址不同，
		 * 如果scope是singleton，那么us1和us2地址相同，
		 */
		System.out.println("us1:"+us1);
		System.out.println("us2:"+us2);
		
		ClassPathXmlApplicationContext ca =(ClassPathXmlApplicationContext)ac;
		ca.close();//销毁
	}

}
