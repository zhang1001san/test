package com.it.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.demo02.OrderService;

public class OrderTest {
	
	
	
	/**
	 * 实例化 Bean 的三种方式
	 */
	@Test
	public void testSaveOrder() {
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
	
		//2.通过id从工厂中获取对象
		OrderService orderService = (OrderService) ac.getBean("orderService");
		//3.调用方法
		orderService.saveOrder();
	}

}
