package com.it.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.it.demo03.CollectionOject;
import com.it.demo03.Person;
import com.it.demo03.Student;
import com.it.demo03.Teacher;
import com.it.demo04.RoleService;

/**
 * 测试依赖注入
 * @author Administrator
 *
 */
public class DependencyInjectionTest {

	/**
	 * 测试构造函数注入
	 */
	@Test
	public void testContructorInjection(){
		//1.创建工厂，解析配置信息,把类变成对象，存入IOC容器中
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		Person person = (Person) ac.getBean("person");
		//查询注入结果
		System.out.println(person);
	}
	
	
	/**
	 * set方式注入
	 */
	@Test
	public void testSetInjection(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		Student student=(Student) ac.getBean("student");
		
		//查看注入结果
		System.out.println(student);
		
	}
	
	
	/**
	 *  p名称空间注入数据（本质还是调用 set方法）
 		 此种方式是通过在 xml中导入 p名称空间，使用 p:propertyName 来注入数据，它的本质仍然是调用类中的
		set 方法实现注入功能。
	 */
	@Test
	public void testPSpaceInjection(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器
		ApplicationContext ac  =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器获取对象
		Teacher teacher =(Teacher) ac.getBean("teacher");
		//查询注入结果
		System.out.println(teacher);
	}
	
	/**
	 * 测试给集合和数组注入数据
	 */
	@Test
	public void testCollectionInjection(){
		//1.创建工厂，解析配置文件，把类变成对象，存入IOC容器中
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		CollectionOject collectionObject= (CollectionOject) ac.getBean("collectionObject");
		
		//查看注入结果
		System.out.println(collectionObject);
	}
	
	
	/**
	 * 测试：对RoleServiceImpl的roleDao 进行set数据注入
	 */
	@Test
	public void testRoleService(){
		//1.创建工厂，解析配置文件，把类变对象，存入IOC容器中
		ApplicationContext ac =new ClassPathXmlApplicationContext("applicationContext.xml");
		//2.通过id从IOC容器中获取对象
		RoleService roleService  =(RoleService) ac.getBean("roleService");
		//3.调用方法
		roleService.save();
	}
	
}
