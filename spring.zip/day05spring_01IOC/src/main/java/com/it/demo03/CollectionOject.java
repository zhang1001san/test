package com.it.demo03;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * 注入集合属性
 * @author Administrator
 *
 */
public class CollectionOject {
	private String[] strArray;
	private List<String> list;
	private Set<String> set;
	private Map<String, String> map;
	private Properties props;
	
	private Student[] studentArray;//存入是Student对象
	private List<Student> studentList;//存入的是Student对象
	private Map<String, Student> studentMap;//存入的是Student对象
	
	
	public void setStrArray(String[] strArray) {
		this.strArray = strArray;
	}
	public void setList(List<String> list) {
		this.list = list;
	}
	public void setSet(Set<String> set) {
		this.set = set;
	}
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	public void setProps(Properties props) {
		this.props = props;
	}
	public void setStudentArray(Student[] studentArray) {
		this.studentArray = studentArray;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	public void setStudentMap(Map<String, Student> studentMap) {
		this.studentMap = studentMap;
	}
	
	@Override
	public String toString() {
		return "CollectionOject [strArray=" + Arrays.toString(strArray) + ", list=" + list + ", set=" + set + ", map="
				+ map + ", props=" + props + ", studentArray=" + Arrays.toString(studentArray) + ", studentList="
				+ studentList + ", studentMap=" + studentMap + "]";
	}

}
