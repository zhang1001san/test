package com.it.demo03;

import java.util.Date;

public class Person {
	private String name;
	private Integer age;
	private Date birthday;
	
	/**
	 * 构造函数注入
	 * @param name
	 * @param age
	 * @param birthday
	 */
	public Person(String name, Integer age, Date birthday) {
		super();
		this.name = name;
		this.age = age;
		this.birthday = birthday;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", birthday=" + birthday + "]";
	}
}
