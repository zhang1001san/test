package com.it.demo03;

import java.util.Date;


/**
 * p名称空间注入数据（本质还是调用 set方法）
 		此种方式是通过在 xml中导入 p名称空间，使用 p:propertyName 来注入数据，它的本质仍然是调用类中的
		set 方法实现注入功能。
 * @author Administrator
 *
 */
public class Teacher {
	private String name;
	private Integer age;
	private Date birthday;
	
	
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	@Override
	public String toString() {
		return "Teacher [name=" + name + ", age=" + age + ", birthday=" + birthday + "]";
	}
	
}
