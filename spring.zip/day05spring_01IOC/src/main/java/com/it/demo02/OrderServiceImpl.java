package com.it.demo02;

/**
 * 实例化 Bean 的三种方式
 * @author Administrator
 *
 */
public class OrderServiceImpl implements OrderService {


	@Override
	public void saveOrder() {
		System.out.println("OrderServiceImpl   保存订单...");
	}

}
