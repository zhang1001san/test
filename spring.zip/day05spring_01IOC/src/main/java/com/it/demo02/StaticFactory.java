package com.it.demo02;

/**
 * 使用静态工厂创建对象
 * @author Administrator
 *
 */
public class StaticFactory {
	
	
	/**
	 * 使用静态工厂创建对象
	 * @return
	 */
	public  static OrderService createOrderService(){
		System.out.println("使用静态工厂创建对象");
		return new OrderServiceImpl();
	} 

}
