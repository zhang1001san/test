package com.it.demo02;

/**
 * 实例化工厂方式创建对象
 * @author Administrator
 *
 */
public class InstanceFactory {
	
	/**
	 * 实例化工厂方式创建对象
	 * @return
	 */
	public OrderService getOrderService(){
		System.out.println("实例化工厂方式创建对象");
		return new OrderServiceImpl();
	}

}
