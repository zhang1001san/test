package com.it.demo02;

public interface OrderService {

	public void saveOrder();
}
