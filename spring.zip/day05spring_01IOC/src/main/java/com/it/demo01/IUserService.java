package com.it.demo01;

public interface IUserService {
	
	/**
	 * 保存
	 */
	public void save();

}
