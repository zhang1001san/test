package com.it.demo01;

/**
 * IUserService 实现类，要交给IOC容器管理的类
 * @author Administrator
 *
 */
public class UserServiceImpl implements IUserService {

	
	
	public UserServiceImpl() {
		super();
		System.out.println("创建UserServiceImpl...");
	}
	
	public void init(){
		System.out.println("init初始化UserServiceImpl");
	}
	
	public void destroy(){
		System.out.println("destroy销毁UserServiceImpl");
	}

	@Override
	public void save() {
		System.out.println("IOC 管理");
	}

}
