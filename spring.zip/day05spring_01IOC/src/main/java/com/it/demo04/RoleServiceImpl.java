package com.it.demo04;

public class RoleServiceImpl implements RoleService {
	private RoleDao roleDao;//要写setRoleDao()方法
	
	public void setRoleDao(RoleDao roleDao) {
		this.roleDao = roleDao;
	}


	@Override
	public void save() {
		System.out.println("业务层:保存");
		//调用持久层的save方法
		roleDao.save();
	}

}
