package com.it.demo04;

public interface RoleService {
	
	public void save();

}
