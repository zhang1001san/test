package com.it.demo04;

public class RoleDaoImpl implements RoleDao {

	@Override
	public void save() {
		System.out.println("持久层: 保存...");
	}

}
