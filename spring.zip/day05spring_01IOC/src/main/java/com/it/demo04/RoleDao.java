package com.it.demo04;

public interface RoleDao {
	
	public void save();

}
