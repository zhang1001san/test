package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 模糊查询
	 * @param username
	 * @return
	 * @throws Exception 
	 */
	public List<User> findUserByUsername(String username) throws Exception;
	
	
	/**
	 * 添加用户
	 * @param user
	 * @throws Exception 
	 */
	public void insertUser(User user) throws Exception;

}
