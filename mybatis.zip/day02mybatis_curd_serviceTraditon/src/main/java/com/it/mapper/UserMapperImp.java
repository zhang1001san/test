package com.it.mapper;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.it.domain.User;

public class UserMapperImp implements UserMapper {

	/**
	 * 模糊查询用户
	 * @throws Exception 
	 */
	@Override
	public List<User> findUserByUsername(String username) throws Exception {
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.session提供增删改查的方法
		List<User> list = session.selectList("com.it.mapper.UserMapper.findUserByUsername", username);
		
		//5.释放资源
		session.close();
		is.close();
		return list;
	}

	/**
	 * 添加用户
	 * @throws Exception 
	 */
	@Override
	public void insertUser(User user) throws Exception {
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.session提供的添加方法
		session.insert("com.it.mapper.UserMapper.insertUser", user);
		
		//5.提交事务
		session.commit();
		//6.释放资源
		session.close();
		is.close();
	}

}
