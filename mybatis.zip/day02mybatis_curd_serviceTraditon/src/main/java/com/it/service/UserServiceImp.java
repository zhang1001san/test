package com.it.service;

import java.util.List;

import com.it.domain.User;
import com.it.mapper.UserMapper;
import com.it.mapper.UserMapperImp;

public class UserServiceImp implements UserService{

	private UserMapper userMapper = new UserMapperImp();
	
	
	/**
	 * 模糊查询用户
	 */
	@Override
	public List<User> findUserByUsername(String username)throws Exception {
		return userMapper.findUserByUsername(username);
	}

	
	/**
	 * 添加用户
	 */
	@Override
	public void insertUser(User user) throws Exception{
		userMapper.insertUser(user);
	}

}
