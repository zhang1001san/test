package com.it.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.it.domain.User;
import com.it.service.UserService;
import com.it.service.UserServiceImp;

public class UserTest {
	private UserService userService = new UserServiceImp();
	
	/**
	 * 模糊查询用户
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByUsername() throws Exception{
		List<User> list = userService.findUserByUsername("%王%");
		for (User user : list) {
			System.out.println(user);
		}
	}
	
	
	/**
	 * 添加用户
	 * @throws Exception 
	 */
	@Test
	public void testInsertUser() throws Exception{
		User user = new User();
		user.setUsername("赵敏");
		user.setBirthday(new Date());
		user.setSex("女");
		user.setAddress("北京");
		userService.insertUser(user);
		
	}

}
