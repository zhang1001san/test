package com.it.domain;

import java.io.Serializable;

/**
 * 传递 pojo包装对象:
	   	开发中通过 pojo 传递查询条件 ，查询条件是综合的查询条件，不仅包括用户查询条件还包括
		其它的查询条件（比如将用户购买商品信息也作为查询条件），这时可以使用包装对象传递输入参数。
		Pojo类中包含 pojo。
	需求：根据用户名查询用户信息，查询条件放到 QueryVo 的 user 属性中。
 * @author Administrator
 *
 */


public class QueryVo implements Serializable{
	

	private static final long serialVersionUID = 4112827428920337024L;
	private String name;
	private User user;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	

}
