package com.it.mapper;

import java.util.List;

import com.it.domain.QueryVo;
import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 查询所有用户
	 * @return
	 */
	public List<User> findAllUser();
	
	/**
	 * 添加用户
	 * @param user
	 * @return
	 */
	public Integer insertUser(User user);
	
	
	/**
	 * 修改用户信息
	 * @param user
	 */
	public void updateUser(User user);
	
	/**
	 * 通过用户id删除对象
	 * @param id
	 */
	public void deleteUser(Integer id);
	
	/**
	 * 模糊查询、
	 * 通过username查询用户
	 * @param username
	 * @return
	 */
	public List<User> findUserByUsername(String username);
	
	
	/**
	 *  通过pojo包装对象
	 *  模糊查询用户
	 * @param vo
	 * @return
	 */
	public User findUserByQueryVo(QueryVo vo);
	
	
	/**
	 * 聚合函数
	 * 查询所有的用户的记录数
	 * @return
	 */
	public Integer findTotalRecords();
	
	
	/**
	 * 	解决sql 查询字段名和 pojo 的属性名不一致问题:
	 *	 resultType 可以指定 pojo 将查询结果映射为 pojo，但需要 pojo 的属性名和 sql 查询的列名一致
		方可映射成功。
		如果 sql 查询字段名和 pojo 的属性名不一致，可以通过 resultMap 将字段名和属性名作一个对应
		关系 ，resultMap 实质上还需要将查询结果映射到 pojo对象中。
		resultMap 可以实现将查询结果映射为复杂类型的 pojo，比如在查询结果映射对象中包括 pojo
		和 list 实现一对一查询和一对多查询。
	 * @return
	 */
	public List<User> findUserByAlias(String username);

}
