package com.it.test;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.QueryVo;
import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	
	
	/**
	 * 测试查询所有用户数据
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser() throws Exception{
		//解析配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//创建SqlSessionFactory
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//创建SqlSession对象
		SqlSession session = factory.openSession();
		
		UserMapper mapper = session.getMapper(UserMapper.class);
		List<User> list = mapper.findAllUser();
		for (User user : list) {
			System.out.println(user);
		}
		
		//释放资源
		session.close();
		is.close();
	}
	
	/**
	 * 测试添加用户
	 * @throws Exception 
	 */
	@Test
	public void testInsertUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory 
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		
		//4执行操作
		//获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		User user = new User();
		user.setUsername("熊大");
		user.setBirthday(new Date());
		user.setAddress("森林");
		user.setSex("男");
		//调用方法
		Integer result = mapper.insertUser(user);
		System.out.println("影响的行数:"+result);
		System.out.println(user);
		
		
		
		/**
		 * 打开 Mysql 数据库发现并没有添加任何记录，原因是什么？
			这一点和 jdbc 是一样的，我们在实现增删改时一定要去控制事务的提交，那么在 mybatis 中如何控
			制事务提交呢？
			可以使用:session.commit();来实现事务提交。
		 */
		//5.提交事务
		session.commit();
		
		
		//6.释放资源
		session.close();
		is.close();
		
	}
	
	
	/**
	 * 添加用户
	 * @throws Exception
	 */
	@Test
	public void testUpdateUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory 对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession 对象
		SqlSession session = factory.openSession();
		
		
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		User user = new User();
		user.setId(56);
		user.setBirthday(new Date());
		user.setUsername("熊二");
		user.setSex("男");
		user.setAddress("森林深处旁边");
		//调用方法
		mapper.updateUser(user);
		
		
		//5.提交事务
		session.commit();
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 删除用户
	 * @throws Exception 
	 */
	@Test
	public void testDeleteUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession 
		SqlSession session = factory.openSession();
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		//5.调用方法
		mapper.deleteUser(54);
		
		//6.提交事务
		session.commit();
		
		//7.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 测试模糊查询
	 * 通过用户名模糊查询用户
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByUsername() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		//5.调用方法
		List<User> list = mapper.findUserByUsername("%王%");
		
//		第二种模糊查询方法
//		List<User> list = mapper.findUserByUsername("王");
		
		for (User user : list) {
			System.out.println(user);
		}
		
		//6.释放资源
		session.close();
		is.close();
		
		
	}
	
	
	/**
	 * 传递 pojo包装对象
	 * 模糊查询用户
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByQueryVo() throws Exception{
	
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
	
		QueryVo queryVo = new QueryVo();
		queryVo.setName("哈哈哈");
		User user = new User();
		user.setUsername("熊二");
		//查询结果必须只有一个。否则报错：org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 2
		


		queryVo.setUser(user);
		
		//5.调用方法
		User resultUser = mapper.findUserByQueryVo(queryVo);
		System.out.println(resultUser);
		
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 聚合函数，
	 * 查询所有用户的 记录数
	 * @throws Exception 
	 */
	@Test
	public void testFindTotalRecords() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		Integer totalRecords = mapper.findTotalRecords();
		System.out.println("总记录数为:"+totalRecords);
		
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 解决 sql查询字段名和 pojo的属性名不一致问题:
	 * 	通过定义resultType
	 * 		由于上边的 mapper.xml 中 sql 查询列和 Users.java 类属性不一致，需要定义 resultMap：
			userListResultMap 将 sql 查询列和Users.java类属性对应起来
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByAlias() throws Exception{
		//1.读取配置信息
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory 对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		//5调用方法
		List<User> list = mapper.findUserByAlias("%王%");
		for (User user : list) {
			System.out.println(user);
		}
		
		
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	
	
	

}
