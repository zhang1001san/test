package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 模糊查询
	 * 通过username查询符合条件的用户
	 * @param username
	 * @return
	 */
	public List<User> findUserByUsername(String username);
	
	
	/**
	 * 添加用户
	 * @param user
	 */
	public void insertUser(User user);

}
