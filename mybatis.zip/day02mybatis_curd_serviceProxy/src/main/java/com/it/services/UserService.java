package com.it.services;

import java.util.List;

import com.it.domain.User;

public interface UserService {
	
	
	
	public List<User> findUserByUsername(String username) throws Exception;
	
	public void insertUser(User user) throws Exception;
	
	

}
