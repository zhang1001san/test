package com.it.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.it.domain.User;
import com.it.services.UserService;
import com.it.services.UserServiceImp;

public class UserTest {
	
	private UserService  userService= new UserServiceImp();
	
	
	/**
	 * 测试模糊查询
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByUsername() throws Exception{
		List<User> list = userService.findUserByUsername("%王%");
		for (User user : list) {
			System.out.println(user);
		}
		
	}
	
	
	/**
	 * 添加用户
	 * @throws Exception 
	 */
	@Test
	public void testInsertUser() throws Exception{
	
		User user = new User();
		user.setUsername("张三");
		user.setBirthday(new Date());
		user.setSex("女");
		user.setAddress("银河系");
		
		userService.insertUser(user);
	}
	
	
	
	

}
