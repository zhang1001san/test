package com.it.domain;

import java.io.Serializable;
import java.util.List;

/**
 * `ID` int(11) NOT NULL COMMENT '编号',
  `ROLE_NAME` varchar(30) default NULL COMMENT '角色名称',
  `ROLE_DESC` varchar(60) default NULL COMMENT '角色描述',
 * @author Administrator
 *
 */
public class Role implements Serializable {

	private static final long serialVersionUID = -4925897885116070000L;
	
	private Integer id;//编号
	private String role_name;//角色名称
	private String role_desc; //角色描述
	
	private List<User> userList;//当前角色下所有用户
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public String getRole_desc() {
		return role_desc;
	}
	public void setRole_desc(String role_desc) {
		this.role_desc = role_desc;
	}
	
	public List<User> getUserList() {
		return userList;
	}
	public void setUserList(List<User> userList) {
		this.userList = userList;
	}
	@Override
	public String toString() {
		return "Role [id=" + id + ", role_name=" + role_name + ", role_desc=" + role_desc + "]";
	}


}
