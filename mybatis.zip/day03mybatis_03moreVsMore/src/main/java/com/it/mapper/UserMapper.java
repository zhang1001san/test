package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 查询当前用户下有多少个角色
	 * @return
	 */
	public List<User> findUserWithRole();
	
}
