package com.it.mapper;

import java.util.List;

import com.it.domain.Role;

public interface RoleMapper {
	
	/**
	 * 查询当前角色下的所有用户
	 * @return
	 */
	public List<Role> findRoleWithUser();
 
}
