package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.Role;
import com.it.domain.User;
import com.it.mapper.RoleMapper;
import com.it.mapper.UserMapper;

public class UserTest {
	
	
	/**
	 * 查询当前角色下的所有用户：一对多
	 * @throws Exception 
	 */
	@Test
	public void testFindRoleWithUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		RoleMapper mapper = session.getMapper(RoleMapper.class);
		
		//5.调用方法
		List<Role> list = mapper.findRoleWithUser();
		for (Role role : list) {
			System.out.print(role);
			System.out.println("  "+role.getUserList());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 查询当前用户下有多少个角色  一对多
	 * @throws Exception 
	 */
	@Test
	public void testFindUserWithRole() throws Exception{
		// 1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 3.创建SqlSession
		SqlSession session = factory.openSession();
		// 4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findUserWithRole();
		for (User user : list) {
			System.out.print(user);
			System.out.println("  "+user.getRoleList());
		}
		
		
		//6.释放资源
		session.close();
		is.close();
	}

}
