package com.it.mapper;

import java.util.List;

import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.FetchType;

import com.it.domain.Account;

public interface AccountMapper {
	
	/**
	 * 延迟加载：多对一
	 * 查询出所有的账号信息，采用延迟加载方式查询用户的信息
	 * @Results	相对于 resultMap标签
	 * @Result 相当于 result或者id标签
	 * 
	 * @Result(id=true,property="id",column="id") == <id property="id" column="id"/>
	 * 
	 * @return
	 */
	@Select("select * from account")
	@Results(value={
		@Result(id=true,property="id",column="id"),
		@Result(property="uid" ,column="uid"),
		@Result(property="money",column="money"),
		@Result(property="mUser",column="uid",one=@One(select="com.it.mapper.UserMapper.findUserById",fetchType=FetchType.LAZY))
			
	})
	public List<Account> findAllAccountByLazyLoad();
	
	
	
	/**
	 * 立即加载：多对一
	 * 查询出所有的账号信息，采用立即加载方式查询用户的信息
	 * @return
	 */
	@Select("SELECT * FROM account a LEFT JOIN USER u ON a.UID=u.id")
	@Results(value={
		@Result(id=true,property="id" ,column="id"),
		@Result(property="uid",column="uid"),
		@Result(property="money",column="money"),
		@Result(property="mUser.id",column="uid"),
		@Result(property="mUser.username",column="username"),
		@Result(property="mUser.birthday",column="birthday"),
		@Result(property="mUser.sex",column="sex"),
		@Result(property="mUser.address",column="address")
	})
	public List<Account> findAllAccount();
	
	
	/**
	 * 根据用户的id查询账号
	 * @param uid
	 * @return
	 */
	@Select("select * from account where uid=#{uid}")
	public Account findAccountByUid(Integer uid);

}
