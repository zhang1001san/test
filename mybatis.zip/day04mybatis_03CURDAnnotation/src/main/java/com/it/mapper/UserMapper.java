package com.it.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;

import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 查询所有用户
	 * @return
	 */
	// @Select(value= {"",""})	给多个值
	// @Select(value= "")		给一个值
	// @Select("sql语句")		只编写一个属性，并且属性的名称是value，那么value可以省略不写
	@Select("select * from user")
	public List<User> findAllUser();
	
	
	/**
	 * 通过用户id查询用户
	 * @param id
	 * @return
	 */
	@Select("select * from user where id=#{id}")
	public User findUserById(Integer id);

	/**
	 * 通过注解添加用户
	 * @param user
	 */
	@Insert("insert into user(username,birthday,sex,address)  values(#{username},#{birthday},#{sex},#{address})")
	public void addUser(User user);
	
	
	/**
	 * 通过注解删除用户
	 * @param id
	 */
	@Delete("delete from user where id=#{id}")
	public void deleteUser(Integer id);
	
	
	/**
	 * 通过注解修改用户
	 * @param user
	 */
	@Update("update user set username=#{username},sex=#{sex},address=#{address} where id=#{id}")
	public void updateUser(User user);
	
	
	/**
	 * 查询所有用户的记录
	 * 聚合函数
	 * @return
	 */
	@Select("select count(*) from user ")
	public Integer findTotalRecords();
	
	/**
	 * 模糊查询
	 * @param username
	 * @return
	 */
	@Select("select * from user where username like #{username}")
	public List<User> findUserByUsername(String username);
	
	
	/**
	 * 一对多，延迟加载
	 * 
	 * @return
	 */
	@Select("select * from user")
	@Results(value={
		@Result(id=true,property="id" ,column="id"),
		@Result(property="username" ,column="username"),
		@Result(property="birthday",column="birthday"),
		@Result(property="sex",column="sex"),
		@Result(property="address",column="address"),
		@Result(property="accountList" ,column="id",many=@Many(select="com.it.mapper.AccountMapper.findAccountByUid",fetchType=FetchType.LAZY))
	})
	public List<User> findAllUserWithAccount();
	
	
	
}
