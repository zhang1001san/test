package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.Account;
import com.it.mapper.AccountMapper;

public class AccountTest {
	
	
	/**延迟加载：
	 * 		多对一
	 * 查询所有用户，当需要的时候，查询当前用户下 的所有账号
	 * @throws Exception 
	 * 
	 */
	@Test
	public void testFindAllAccountByLazyLoad() throws Exception{
		
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<Account> list = mapper.findAllAccountByLazyLoad();
		for (Account account : list) {
			System.out.println(account.getMoney());
			//延迟加载
			System.out.println(account.getmUser().getUsername());
			System.out.println("========================");
		}
		
		//6.释放资源
		session.close();
		is.close();
		
	}
	
	/**
	 * 立即加载
	 * 		多对一
	 * 查询所有用户，当需要的时候，查询当前用户下 的所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllAccount() throws Exception{
		//1.读取配置文件
		InputStream is= Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<Account> list = mapper.findAllAccount();
		for (Account account : list) {
			System.out.print(account);
			System.out.println(account.getmUser());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}

}
