package com.it.test;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	
	/**
	 * 查询所有用户
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findAllUser();
		for (User user : list) {
			System.out.println(user);
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 通过用户id查询用户
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		User user = mapper.findUserById(48);
		System.out.println(user);
		
		//6.释放资源
		session.close();
		is.close();
		
	}
	
	/**
	 * 使用注解添加用户
	 * @throws Exception 
	 */
	@Test
	public void testAddUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		User user = new User();
		user.setUsername("小昭");
		user.setSex("女");
		user.setBirthday(new Date());
		user.setAddress("波斯");
		
		mapper.addUser(user);
		
		//6.提交事务
		session.commit();
		//7.释放资源
		session.close();
		is.close();
		
	}
	
	/**
	 * 通过注解删除用户
	 * @throws Exception 
	 */
	@Test
	public void testDeleteUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		mapper.deleteUser(50);
		
		//6.提交事务
		session.commit();
		
		//7.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 通过注解修改用户
	 * @throws Exception 
	 */
	@Test
	public void testUpdateUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		User user = new User();
		user.setId(51);
		user.setUsername("赵敏");
		user.setAddress("光明顶");
		user.setSex("女");
		mapper.updateUser(user);
		
		//6.提交事务
		session.commit();
		//7.释放资源
		session.close();
		is.close();
	}
	
	
	
	/**
	 * 查询所有用户的记录
	 * 聚合函数
	 * @throws Exception 
	 */
	@Test
	public void testFindTotalRecords() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		Integer totalRecords = mapper.findTotalRecords();
		
		System.out.println("总记录数："+totalRecords);
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 模糊查询
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByUsername() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findUserByUsername("%王%");
		for (User user : list) {
			System.out.println(user);
		}
		
		//6.释放资源
		session.close();
		is.close();
	}

	
	
	/**
	 * 一对多，延迟加载
	 * 通过注解，查询所有用户，当需要查询当前用户下的所有账号时，在查询当前用户下的所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUserWithAccount() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		
		//5.调用方法
		List<User> list = mapper.findAllUserWithAccount();
		for (User user : list) {
			System.out.println(user.getUsername());
			//延迟加载
			System.out.println("account:"+user.getAccountList());
			System.out.println("=============================");
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
}
