package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;
import com.it.mybatis.Resources;
import com.it.mybatis.SqlSession;
import com.it.mybatis.SqlSessionFactory;
import com.it.mybatis.SqlSessionFactoryBuilder;

public class UserTest {
	

	/**
	 * 查询所有用户
	 * 自定义mybatis使用动态代理
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser() throws Exception{
		//1.加载配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory 对象 。创建者设计模式创建工厂对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.通过session创建UserMapper接口的代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		//5.查询所用用户
		List<User> list = mapper.findAllUser();
		
		//6.遍历
		for (User user : list) {
			System.out.println(user);
		}
		
		//7.释放资源
		session.close();
		is.close();
		
	}

}
