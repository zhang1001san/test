package com.it.mybatis;

import java.io.InputStream;

/**
 * 读取配置文件
 * @author Administrator
 *
 */
public class Resources {

	/**
	 * 读取配置文件，返回值输入流
	 * @param resource
	 * @return
	 */
	public static InputStream getResourceAsStream(String resource) {
		if(resource==null || "".equals(resource)){
			throw new RuntimeException("读取配置文件出错");
		}
		
		return Resources.class.getClassLoader().getResourceAsStream(resource);
		 
	}

}
