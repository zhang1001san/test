package com.it.mybatis;

import java.io.InputStream;

/**
 * 创建者设计模式生产SqlSessionFactory对象
 * @author Administrator
 */
public class SqlSessionFactoryBuilder {

	public SqlSessionFactory build(InputStream is) throws Exception {
		//1. 解析SqlMapConfig.xml配置文件，把xml中内容全部都存储到Configuration对象中
		Configuration configuration = XMLConfigBuilder.buildConfiguration(is);
		//2.把configuration对象传给SqlSessionFactory对象
		DefaultSqlSessionFactory factory = new DefaultSqlSessionFactory(configuration);
		return factory;
	}

}
