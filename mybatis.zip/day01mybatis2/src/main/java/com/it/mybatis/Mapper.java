package com.it.mybatis;

/**
 * 用于封装UserMapper配置文件信息
 * @author Administrator
 */
public class Mapper {
	
	// 表示要执行的SQL语句
	private String querySql;
	// 表示返回的数据类型
	private String resultType;
	
	public String getQuerySql() {
		return querySql;
	}
	public void setQuerySql(String querySql) {
		this.querySql = querySql;
	}
	public String getResultType() {
		return resultType;
	}
	public void setResultType(String resultType) {
		this.resultType = resultType;
	}
}
