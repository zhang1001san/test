package com.it.mybatis;

public interface SqlSessionFactory {

	SqlSession openSession();

}
