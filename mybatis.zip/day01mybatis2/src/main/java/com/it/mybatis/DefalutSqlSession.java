package com.it.mybatis;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

public class DefalutSqlSession implements SqlSession {
	// 配置文件所有的信息
	private Configuration configuration;
	
	
	public DefalutSqlSession(Configuration configuration) {
		super();
		this.configuration = configuration;
	}

	/**
	 * 获取到代理对象
	 * 准备使用JDK动态代理执行方法
	 */
	@Override
	public <T> T getMapper(Class<T> clazz) {
		
		Object object = Proxy.newProxyInstance(clazz.getClassLoader(),  new Class [] {clazz}, new InvocationHandler() {
			
			/**
			 * 调用代理对象的方法，invoke方法就会执行
			 * 对findAllUser这些方法进行增强
			 */
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				//1.指定sql语句
				Executor executor = new Executor(configuration);
				//2.UserMapper.xml配置文件中取
				Map<String, Mapper> mappers = configuration.getMappers();
				
//				mappers.get("findAllUser");
				Mapper mapper = mappers.get(method.getName());
				//3.执行查询
				return	executor.executeQuery(mapper.getQuerySql(), mapper.getResultType());
			
			}
		});
		
		
		return (T) object;
	}

	@Override
	public void close() {
		System.out.println("关闭资源。。。");
	}

}
