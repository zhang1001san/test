package com.it.mybatis;

public interface SqlSession {

	 <T> T getMapper(Class<T> clazz);

	void close();

}
