package com.it.mybatis;

public class DefaultSqlSessionFactory implements SqlSessionFactory {

	private Configuration configuration;
	
	public DefaultSqlSessionFactory(Configuration configuration) {
		super();
		this.configuration = configuration;
	}


	/**
	 * 创建新的session对象，返回
	 * configuration继续传给SqlSession对象
	 */
	@Override
	public SqlSession openSession() {
		DefalutSqlSession session = new DefalutSqlSession(configuration);
		return session;
	}

}
