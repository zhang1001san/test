package com.it.domain;

import java.io.Serializable;

/**
 * 封装用户表和账号表内连接查询出来的记录
 * @author Administrator
 *
 */

public class AccountUser extends Account implements Serializable{

	private static final long serialVersionUID = -1719348447142779481L;
	
	public String username;
	public String sex;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	
	@Override
	public String toString() {
		return "id="+getId()+" uid="+getUid()+"  money="+getMoney()+" username="+username+"  sex="+sex;
	}
	
	
	

}
