package com.it.mapper;

import java.util.List;

import com.it.domain.Account;
import com.it.domain.AccountUser;

public interface AccountMapper {
	
	/**
	 * 多对一(即一对一)查询方式一:
	 * 		查询的数据中包含account所有的字段，再包含用户的名称和地址
	 * @return
	 */
	public List<AccountUser> findAccountUser();
	
	
	/**
	 * 多对一查询方式二
	 * 		查询的数据中包含account所有的字段，再包含用户的名称和地址
	 * 		在Account类中添加user的属性，表示该帐户只属于这个用户
	 * @return
	 */
	public List<Account> findAccount();
	

}
