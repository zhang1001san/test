package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {

	/**
	 * 需求：查询所有用户信息及用户关联的账户信息。
		分析：用户信息和他的账户信息为一对多关系，并且查询过程中如果用户没有账户信息，此时也要
		将用户信息查询出来，我们想到了左外连接查询比较合适。
	 * @return
	 */
	public List<User> findUserWithAccount();
}
