package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.Account;
import com.it.domain.AccountUser;
import com.it.domain.User;
import com.it.mapper.AccountMapper;
import com.it.mapper.UserMapper;

/**
 * 
 * 用户和订单：一对多
 * 	1. 一对一    其实一对一可以设计成一张表结构
	2. 一对多
	3. 多对一     在MyBatis框架中，可以把多对一看成一对一
	4. 多对多

 *
 */

public class UserTest {
	
	
	/**
	 * 多对一(即一对一)查询方式一:
	 * 	     查询的数据中包含account所有的字段，再包含用户的名称和地址
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<AccountUser> list = mapper.findAccountUser();
		for (AccountUser accountUser : list) {
			System.out.println(accountUser);
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	/**
	 * 多对一查询方式二
		需求：查询的数据中包含account所有的字段，再包含用户的名称和地址
		在Account类中添加user的属性，表示该帐户只属于这个用户
	 * @throws Exception 
	 */
	@Test
	public void testFindAccount() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<Account> list = mapper.findAccount();
		for (Account account : list) {
			System.out.print(account);
			System.out.println("user="+account.getmUser());
		}
		
		//6.释放资源
		session.close();
		is.close();
		
	}
	
	
	/**
	 * 需求：查询所有用户信息及用户关联的账户信息。
		分析：用户信息和他的账户信息为一对多关系，并且查询过程中如果用户没有账户信息，此时也要
		将用户信息查询出来，我们想到了左外连接查询比较合适。
	 * @throws Exception 
	 */
	@Test
	public void testFindUserWithAccount() throws Exception{
		// 1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 3.创建SqlSession
		SqlSession session = factory.openSession();
		// 4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findUserWithAccount();
		for (User user : list) {
			System.out.print(user);
			System.out.println("   account:"+user.getAccountList());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	

}
