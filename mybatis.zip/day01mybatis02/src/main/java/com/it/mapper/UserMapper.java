package com.it.mapper;

import java.util.List;

import com.it.domain.User;



/**
 * 以前的UserDao接口，数据访问层
 * 没有编写实现类，MyBatis框架会帮你生成实现类对象
 * @author Administrator
 */
public interface UserMapper {

	/**
	 * 查询所有用户
	 * @return
	 */
	public List<User> findAllUser();
}
