package com.it.mapper;

import com.it.domain.User;

public interface UserMapper {
	
	/**
	 * 通过用户的id查询用户
	 * @param id
	 * @return
	 */
	public User findUserById(Integer id);
	
	/**
	 * 修改用户
	 * @param user
	 */
	public void updateUser(User user);
	
	
	/**
	 * 查询用户，使用二级缓存
	 * @param id
	 * @return
	 */
	public User findUserWithCache(Integer id);

}
