package com.it.test;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	

	/**
	 * 一级缓存是 SqlSession 级别的缓存，只要 SqlSession 没有flush或 close，它就存在。
	 * 通过用户的 id查询用户
	 * 
	 * SqlSession级别的缓存
	 * 默认就存在，默认就是使用的
	 * 存储 k 执行SQL语句  v 对象
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		// 查询用户对象，先查询缓存，如果有，返回。没有，查询数据库，看到SQL语句
		// 把user1对象存入到一级缓存中
		User user1 = mapper.findUserById(48);
		// 再查询一次，先查询缓存，缓存已经存在了，不查询数据库。没有SQL语句
		User user2 = mapper.findUserById(48);
		System.out.println(user1);
		System.out.println(user2);
		
		//user1和user2的地址一样
		
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	/**
		清除缓存
	 * 一级缓存是 SqlSession 范围的缓存，当调用 SqlSession 的修改，添加，删除，commit()，close()等方
		法时，就会清空一级缓存。
		
		测试这个方法的时候，把SqlMapConfig.xml中 value 改为false,即不开启二级缓存
		<setting name="cacheEnabled" value="false"/>
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById2() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		// 查询用户对象，先查询缓存，如果有，返回。没有，查询数据库，看到SQL语句
		// 把user1对象存入到一级缓存中
		User user1 = mapper.findUserById(48);
		System.out.println(user1);
		
		
		//6.清除一级缓存
		session.close();
		
		//创建新的session
		SqlSession session2 = factory.openSession();
		UserMapper mapper2 = session2.getMapper(UserMapper.class);
		
		// 调用查询。因为一级缓存是SqlSession级别的缓存，关闭session在创建新的session对象
		//会把一级缓存清除。因此user1和user2的地址不一样
		User user2 = mapper2.findUserById(48);
		System.out.println(user2);
		
		
		//7.释放资源
		session2.close();
		is.close();
	}
	
	/**
	 * 清除一级缓存
	 * 一级缓存是 SqlSession 范围的缓存，当调用 SqlSession 的修改，添加，删除，commit()，close()等方
		法时，就会清空一级缓存。
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById3() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		User user1 = mapper.findUserById(46);
		System.out.println(user1);
		
		/**
		 *  一级缓存是 SqlSession 范围的缓存，当调用 SqlSession 的修改，添加，删除，
		 *  commit()，close()等方法时，就会清空一级缓存。
		 *  所以user1和user2的地址不一样
		 */
		User updateUser = new User();
		updateUser.setAddress("深圳");
		updateUser.setId(48);
		mapper.updateUser(updateUser);
		
		User user2 = mapper.findUserById(46);
		System.out.println(user2);
		
		//6.提交事务
		session.commit();
		
		//7.释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 使用二级缓存查询用户
	 * 	打印发现2个对象的地址值不一样，但是确实只发送了一次SQL语句的查询，二级缓存中存储是数据，不是对象。
		二级缓存的生效必须要调用session.commit()或者session.close()方法才能生效。
		JavaBean的类需要实现Serializable接口

	 * @throws Exception 
	 */
	@Test
	public void testFindUserWithCache() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		User user1 = mapper.findUserWithCache(48);
		System.out.println(user1);
		System.out.println(user1.show());
		//清除一级缓存
		session.close();
		
		//创建新的session
		SqlSession session2 = factory.openSession();
		UserMapper mapper2 = session2.getMapper(UserMapper.class);
		User user2 = mapper2.findUserWithCache(48);
		System.out.println(user2);
		System.out.println(user2.show());
		
		
		//释放资源
		session2.close();
		is.close();
	}
}
