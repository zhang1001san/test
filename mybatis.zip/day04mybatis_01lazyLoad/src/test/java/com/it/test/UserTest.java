package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	
	/**
	 * 立即加载
	 * 查询当前用户，和当前用户下的所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindUserWithAccount() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findUserWithAccount();
		for (User user : list) {
			System.out.print(user);
			System.out.println(user.getAccountList());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
	
	/**
	 * 延迟加载
	 * 查询所有用户，当需要查询当前用户下的所有账号是，再查询当前用户下的所有账号
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByLazyLoad() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		List<User> list = mapper.findUserByLazyLoad();
		for (User user : list) {
			System.out.println(user.getUsername());
			System.out.println(user.getAccountList().size());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}

}
