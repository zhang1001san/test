package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.Account;
import com.it.mapper.AccountMapper;

public class AccountTest {
	
	
	/**立即加载
	 * 		查询所有的账号，如果其对应的用户不为null，也查询其用户
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountWithUser() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<Account> list = mapper.findAccountWithUser();
		for (Account account : list) {
			System.out.print(account);
			System.out.println(account.getmUser());
		}
		
		//6.释放资源
		session.close();
		is.close();
		
		
	}

	
	/**
	 * 延迟加载
	 * 		查询账户(Account)信息并且关联查询用户(User)信息。
	 * 		如果先查询账户(Account)信息即可满足要求，当我们需要查询用户(User)信息时再查询用户(User)信息。
	 * 		把对用户(User)信息的按需去查询就是延迟加载。
	 * @throws Exception 
	 */
	@Test
	public void testFindAccountByLazyLoad() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建工厂
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		//4.获取代理对象
		AccountMapper mapper = session.getMapper(AccountMapper.class);
		
		//5.调用方法
		List<Account> list = mapper.findAccountByLazyLoad();
		for (Account account : list) {
//			System.out.println(account.show());
			System.out.println(account);
			System.out.println(account.getmUser().getUsername());
		}
		
		//6.释放资源
		session.close();
		is.close();
	}
}
