package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {
	
	
	/**立即加载
	 * 查询当前用户，和当前用户下的所有账号
	 * @return
	 */
	public List<User> findUserWithAccount();
	
	
	/**
	 * 延迟加载
	 * 查询用户，当需要查询用户下的账号是，再查询当前用户下的所有账号
	 * @return
	 */
	public List<User> findUserByLazyLoad();
	
	
	/**
	 * 通过用户id查询用户
	 * @param id
	 * @return
	 */
	public User findUserById(Integer id);
	
	
	

}
