package com.it.mapper;

import java.util.List;

import com.it.domain.Account;

public interface AccountMapper {
	
	/**
	 * 立即加载
	 * 		查询所有的账号，如果其对应的用户不为null，也查询其用户
	 * @return
	 */
	public List<Account> findAccountWithUser();
	
	/**
	 * 延迟加载
	 * 		查询账户(Account)信息并且关联查询用户(User)信息。
	 * 		如果先查询账户(Account)信息即可满足要求，当我们需要查询用户(User)信息时再查询用户(User)信息。
	 * 		把对用户(User)信息的按需去查询就是延迟加载。
	 * @return
	 */
	public List<Account> findAccountByLazyLoad();
	
	
	/**
	 * 通过用户的id查询账号
	 * @return
	 */
	public Account findAccountByUid(Integer uid);

}
