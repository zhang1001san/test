package com.it.domain;

import java.io.Serializable;

/**
 * 
 * 账号表
 * @author Administrator
 *
 */
public class Account implements Serializable{

	private static final long serialVersionUID = -6146905035624015655L;
	
	private Integer id;//订单编号
	private Integer uid;//用户编号
	private Double money;//金额
	
	private User mUser;//当前订单属于的用户信息
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	public User getmUser() {
		return mUser;
	}
	public void setmUser(User mUser) {
		this.mUser = mUser;
	}
	
	
	public String show(){
		return "Account [id=" + id + ", uid=" + uid + ", money=" + money + "]";
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", uid=" + uid + ", money=" + money + "]";
	}
	
}
