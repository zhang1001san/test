package com.it.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	/**
	 * 测试查询所有用户方法
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser() throws Exception{
		// 加载配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 创建SqlSessionFactory对象，创建者设计模式创建工厂对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 创建SqlSession对象
		SqlSession session = factory.openSession();
		// 查询所有的数据
		List<User> list = session.selectList("com.it.mapper.UserMapper.findAllUser");
		
		//遍历
		for (User user : list) {
			System.out.println(user);
		}
		
		// 关闭资源
		session.close();
		is.close();
	}
	
	/**
	 * 查询所有用户
	 * 另一种方式：使用动态代理
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser2() throws Exception{
		//1.加载配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory 对象 。创建者设计模式创建工厂对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession对象
		SqlSession session = factory.openSession();
		
		//4.通过session创建UserMapper接口的代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		//5.查询所用用户
		List<User> list = mapper.findAllUser();
		
		//6.遍历
		for (User user : list) {
			System.out.println(user);
		}
		
		//7.释放资源
		session.close();
		is.close();
		
	}
	
	/**
	 * 测试查询某个用户方法
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById() throws Exception{
		// 加载配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 创建SqlSessionFactory对象，创建者设计模式创建工厂对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 创建SqlSession对象
		SqlSession session = factory.openSession();
		// 查询所有的数据
		User user = session.selectOne("com.it.mapper.UserMapper.findUserById");
		
		System.out.println(user);
		// 关闭资源
		session.close();
		is.close();
	}
	/**
	 * 测试查询某个用户方法
	 * @throws Exception 
	 */
	@Test
	public void testFindUserById2() throws Exception{
		// 加载配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 创建SqlSessionFactory对象，创建者设计模式创建工厂对象
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 创建SqlSession对象
		SqlSession session = factory.openSession();
		// 查询所有的数据
		UserMapper mapper = session.getMapper(UserMapper.class);
		User user = mapper.findUserById();
		
		System.out.println(user);
		// 关闭资源
		session.close();
		is.close();
	}
	
}
