package com.it.test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.it.domain.User;
import com.it.mapper.UserMapper;

public class UserTest {
	
	
	/**
	 * 测试查询所有用户
	 * @throws Exception 
	 */
	@Test
	public void testFindAllUser() throws Exception{
		
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		SqlSession session = factory.openSession();
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		List<User> list = mapper.findAllUser();
		for (User user : list) {
			System.out.println(user);
		}
		
		//释放资源
		session.close();
		is.close();
	}
	
	/**
	 * 添加用户:设置自动提交事务
	 * factory.openSession(true);
	 * @throws Exception 
	 */
	@Test
	public void testInsertUser() throws Exception{
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		
		//设置自动提交事务
		SqlSession session = factory.openSession(true);
		
		//获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		User user = new User();
		user.setUsername("小昭");
		user.setBirthday(new Date());
		user.setSex("女");
		user.setAddress("波斯");
		mapper.insertUser(user);
		
		
		//提交事务
		//session.commit();
		
		//释放资源
		session.close();
		is.close();
	}
	
	/**
	 * 通过if where foreach标签来查询用户
	 * 应用场景：
	 * 	当搜索的时候，有两个选项可输入，一个用户名，一个是性别
	 * 当web把这两个参数传到服务端，然后根据用户名和性别查询符合条件的用户，
	 * 但是如果用户名或者性别中某个值为null，那该怎么办？
	 * 	-----sql 语句拼接
	 * select * from user where 1=1
	 * 	1.username!=null： and username like username
	 *  2.sex!=null：      and sex =sex;
	 * @throws Exception 
	 */
	@Test
	public void testFindUserByIf() throws Exception{
		//1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		//2.创建SqlSessionFactory
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		//3.创建SqlSession
		SqlSession session = factory.openSession();
		//4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		User user = new User();
		user.setUsername("%王%");
		user.setSex("女");
		//5.调用反复
		List<User> list = mapper.findUserByIf(user);
		for (User u : list) {
			System.out.println(u);
		}
		
		
		//6释放资源
		session.close();
		is.close();
	}
	
	
	/**
	 * 当查询sql语句类似：
	 * 		SELECT * FROM USER WHERE id=41 OR id=43 OR id=48;
			SELECT * FROM USER WHERE id IN(41,43,48)
		可通过foreach 标签解决	
	 * @throws Exception 
	 */
	@Test
	public void testFindUserbyForeach() throws Exception{
		// 1.读取配置文件
		InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
		// 2.创建SqlSessionFactory
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		// 3.创建SqlSession
		SqlSession session = factory.openSession();
		// 4.获取代理对象
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		//5.调用方法
		ArrayList<Integer> idList = new ArrayList<Integer>();
		idList.add(41);
		idList.add(43);
		idList.add(48);
		
		User user = new User();
		user.setIdList(idList);
		
		List<User> list = mapper.findUserbyForeach(user);
		for (User u : list) {
			System.out.println(u);
		}
		
		//6.释放资源
		session.close();
		is.close();
	}

}
