package com.it.mapper;

import java.util.List;

import com.it.domain.User;

public interface UserMapper {
	
	public List<User> findAllUser();
	
	public void insertUser(User user);
	
	/**
	 * 通过if where foreach标签来查询用户
	 * 应用场景：
	 * 	当搜索的时候，有两个选项可输入，一个用户名，一个是性别
	 * 当web把这两个参数传到服务端，然后根据用户名和性别查询符合条件的用户，
	 * 但是如果用户名或者性别中某个值为null，那该怎么办？
	 * 	-----sql 语句拼接
	 * select * from user where 1=1
	 * 	1.username!=null： and username like username
	 *  2.sex!=null：      and sex =sex;
	 */
	public List<User> findUserByIf(User user);
	
	/**
	 * 当查询sql语句类似：
	 * 		SELECT * FROM USER WHERE id=41 OR id=43 OR id=48;
			SELECT * FROM USER WHERE id IN(41,43,48)
		可通过foreach 标签解决	
	 * @param user
	 * @return
	 */
	public List<User> findUserbyForeach(User user);

}
